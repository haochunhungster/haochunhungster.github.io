﻿# Remnant 2 完整存檔懶人包 — 一鍵安裝
# 用法: powershell -ExecutionPolicy Bypass -File install.ps1
param([switch]$SkipGameCheck, [string]$SaveDir = "")
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not $SkipGameCheck -and (Get-Process -Name "Remnant2*" -ErrorAction SilentlyContinue)) {
    Write-Host "!! 請先完全關閉 Remnant 2 再執行" -ForegroundColor Red; exit 1
}

if (-not $SaveDir) {
    $steamRoot = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Saved Games\Remnant2\Steam"
    if (-not (Test-Path $steamRoot)) { Write-Host "!! 找不到 Remnant 2 存檔資料夾，請先進過一次遊戲" -ForegroundColor Red; exit 1 }
    $SaveDir = (Get-ChildItem $steamRoot -Directory | Select-Object -First 1).FullName
}
if (-not (Test-Path (Join-Path $SaveDir "profile.sav"))) { Write-Host "!! $SaveDir 裡沒有 profile.sav" -ForegroundColor Red; exit 1 }
Write-Host "存檔資料夾: $SaveDir"

# 備份原有存檔（整個資料夾）
$bak = Join-Path $SaveDir ("backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType Directory -Force $bak | Out-Null
Get-ChildItem $SaveDir -File | Copy-Item -Destination $bak
Write-Host "原存檔已完整備份到: $bak" -ForegroundColor Green

# 覆蓋 profile.sav
Copy-Item (Join-Path $Root "profile.sav") (Join-Path $SaveDir "profile.sav") -Force
Write-Host ""
Write-Host "=== 安裝完成！ ===" -ForegroundColor Green
Write-Host "開遊戲即可。若 Steam 跳出雲端同步衝突，一定選「本機檔案/上傳本機」" -ForegroundColor Yellow
Write-Host "想還原的話，把備份資料夾裡的 profile.sav 複製回去即可"
