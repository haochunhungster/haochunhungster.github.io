﻿# Remnant 2 懶人包安裝腳本
# 用法:
#   第一階段: powershell -ExecutionPolicy Bypass -File install.ps1 -Phase 1
#   （進遊戲讀檔一次、回到主選單、完全關閉遊戲）
#   第二階段: powershell -ExecutionPolicy Bypass -File install.ps1 -Phase 2
param(
    [int]$Phase = 1,
    [string]$SaveDir = "",  # 測試用，平常留空自動偵測
    [switch]$SkipGameCheck  # 測試用
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Proj = Join-Path $Root "tools\r2_engrams"

# 0. 前置檢查
if (-not $SkipGameCheck -and (Get-Process -Name "Remnant2*" -ErrorAction SilentlyContinue)) {
    Write-Host "!! 請先完全關閉 Remnant 2 再執行" -ForegroundColor Red; exit 1
}
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) {
    Write-Host "!! 找不到 .NET SDK。請先安裝: winget install Microsoft.DotNet.SDK.8" -ForegroundColor Red; exit 1
}

# 1. 找存檔
if (-not $SaveDir) {
    $steamRoot = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Saved Games\Remnant2\Steam"
    $SaveDir = (Get-ChildItem $steamRoot -Directory | Select-Object -First 1).FullName
}
$profileSav = Join-Path $SaveDir "profile.sav"
if (-not (Test-Path $profileSav)) { Write-Host "!! 找不到 $profileSav" -ForegroundColor Red; exit 1 }
Write-Host "存檔: $profileSav"

# 2. 備份
$bak = Join-Path $SaveDir ("backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType Directory -Force $bak | Out-Null
Copy-Item "$SaveDir\profile.sav" $bak
Write-Host "已備份到 $bak" -ForegroundColor Green

# 3. 編譯
dotnet build "$Proj\R2Engrams.csproj" -c Release -v q | Out-Null
Write-Host "工具編譯完成"

$tmp = Join-Path $env:TEMP "r2_bro"
New-Item -ItemType Directory -Force $tmp | Out-Null

function Run-Step($src, $dst, $step, $desc) {
    Write-Host ">> $desc" -ForegroundColor Cyan
    & dotnet run --project $Proj -c Release --no-build -- $src $dst @step
    if ($LASTEXITCODE -ne 0 -and -not (Test-Path $dst)) { Write-Host "!! 步驟失敗: $desc" -ForegroundColor Red; exit 1 }
    if (-not (Test-Path $dst)) { Copy-Item $src $dst }   # 該步無變更時直接沿用
}

if ($Phase -eq 1) {
    Run-Step $profileSav   "$tmp\s1.sav" @("--items", "$Proj\items_bro_engrams.txt")  "加入 6 個隱藏職業"
    Run-Step "$tmp\s1.sav" "$tmp\s2.sav" @("--items", "$Proj\items_bro_weapons.txt")  "加入 20 把精選武器"
    Run-Step "$tmp\s2.sav" "$tmp\s3.sav" @("--items", "$Proj\items_bro_trinkets.txt") "加入 30 件飾品"
    Run-Step "$tmp\s3.sav" "$tmp\s4.sav" @("--items", "$Proj\items_bro_mods.txt")     "加入模組與突變因子"
    Run-Step "$tmp\s4.sav" "$tmp\s5.sav" @("--fix-weapons", "$Proj\ranged_list.txt")  "修正槍械彈匣資料(防閃退)"
    Run-Step "$tmp\s5.sav" "$tmp\s6.sav" @("--trait-points", "200")                   "特性點 +200"
    Run-Step "$tmp\s6.sav" "$tmp\s7.sav" @("--set-scrap", "500000")                   "廢料補到 50 萬"
    Run-Step "$tmp\s7.sav" "$tmp\s8.sav" @("--max-weapons")                           "全部武器升到滿等"
    Run-Step "$tmp\s8.sav" "$tmp\s9.sav" @("--max-mutators")                          "全部突變因子升到 +10"
    Copy-Item "$tmp\s9.sav" $profileSav -Force
    Write-Host ""
    Write-Host "=== 第一階段完成 ===" -ForegroundColor Green
    Write-Host "接下來: 1) 開遊戲讀檔進到存檔點  2) 回主選單並完全關閉遊戲  3) 執行 install.ps1 -Phase 2"
    Write-Host "(若 Steam 跳出雲端同步衝突，一定選「本機檔案/上傳本機」)" -ForegroundColor Yellow
}
elseif ($Phase -eq 2) {
    Run-Step $profileSav "$tmp\p2.sav" @("--fix-mods", "$Proj\mod_map.txt") "掛上特殊武器內建技能"
    Copy-Item "$tmp\p2.sav" $profileSav -Force
    Write-Host ""
    Write-Host "=== 全部完成！開遊戲驗收 ===" -ForegroundColor Green
}
