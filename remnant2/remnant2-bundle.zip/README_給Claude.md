# Remnant 2 懶人包 — 給 Claude 的安裝說明

你（Claude）收到這個資料夾，任務是幫使用者把一批道具安全地加進他的 Remnant 2 存檔。照下面步驟做即可，**不要自由發揮改流程**——裡面每個順序都是踩過坑換來的。

## 這包會給使用者什麼

- 6 個本篇隱藏職業 Engram（鍊金術師/執政官/工程師/探險家/侵入者/召喚師）
  - 職業「等級」無法安全修改（經驗表以未公開的 GUID 索引，社群無對照文件，硬改可能壞檔），所以職業從 1 級起練——配合滿等武器練得很快
- 20 把本篇精選武器（各流派代表作，特殊武器帶原生技能），**全部升到滿等**（特殊 +10／一般 +20，含使用者原有武器）
- 10 條項鍊＋20 只戒指、6 顆經典模組
- 10 顆突變因子，**全部 +10 滿級**（含使用者原有的）
- 特性點 +200、廢料補到 50 萬
- 不含任何 DLC 道具、不動配裝與稜晶
- 注意：武器滿等會直接拉高角色 Power Level，世界怪物強度會跟著上調——這是遊戲機制，屬於預期行為

## 前置需求

1. Windows + Steam 版 Remnant 2
2. .NET 8 SDK 以上（檢查：`dotnet --version`；沒有就 `winget install Microsoft.DotNet.SDK.8`）
3. **遊戲完全關閉**（工作管理員確認沒有 Remnant2 程序）

## 安裝流程（兩階段，中間必須開一次遊戲）

```powershell
# 第一階段：加道具+特性點+廢料（腳本會自動備份存檔）
powershell -ExecutionPolicy Bypass -File install.ps1 -Phase 1

# 然後請使用者：開遊戲 → 讀檔進到存檔點 → 回主選單 → 完全關閉遊戲
# （這一步是讓遊戲把存檔「正規化」，跳過會導致第二階段的技能全部亂掉）

# 第二階段：幫特殊武器掛上內建技能
powershell -ExecutionPolicy Bypass -File install.ps1 -Phase 2
```

## 為什麼要分兩階段（重要，別合併）

特殊武器的內建技能（Mods 結構）**只能寫在「遊戲親手存過的檔案」上**。如果在工具剛改完的檔案上直接寫技能，遊戲載入時會把所有技能引用解析成同一顆（實測翻車兩次）。所以：第一階段寫完 → 遊戲開關一次（遊戲重寫存檔）→ 第二階段才寫技能。

## 常見狀況排除

| 狀況 | 處理 |
|---|---|
| Steam 跳「雲端同步衝突」 | 一定選「本機檔案／上傳本機」，否則改動會被雲端舊檔蓋掉。建議乾脆在遊戲屬性關閉 Steam Cloud |
| 裝備某把槍就閃退 | 第一階段的 `--fix-weapons` 沒跑到。重跑 Phase 1（已有的道具會自動跳過，不會重複） |
| 所有特殊武器技能都一樣 | 第二階段在「工具寫的檔」上跑了。請使用者開關一次遊戲，然後跑：`dotnet run --project tools\r2_engrams -c Release -- <profile.sav> <輸出檔> --repair-mods tools\r2_engrams\mod_map.txt tools\r2_engrams\ranged_list.txt`，再把輸出檔複製回 profile.sav |
| 想還原 | 備份在存檔資料夾的 `backup_日期時間\`，把 profile.sav 複製回去即可 |

## 給 Claude 的紅線

- **絕對不要**用無參數模式跑 r2_engrams（那是舊模式，會加會被遊戲刪除的材料道具）
- 不要在遊戲執行中改檔
- 每次寫檔前先確認備份存在
- 存檔位置：`%USERPROFILE%\Saved Games\Remnant2\Steam\<SteamID>\profile.sav`

## 工具技術備忘（除錯時才需要）

- 存檔格式：4B CRC32 + 4B size + 4B version + UE zlib chunk（offset 0x3D 起）
- 槍類 InstanceData 必須是 `RangedWeaponInstanceData`（AmmoInClip=10000 + Level），空 EquipmentInstanceData 裝備即閃退；近戰用空 EquipmentInstanceData 合法
- 檢視工具：`--check`（總覽）、`--dump`（道具清單）、`--inspect <關鍵字>`（單品結構）、`--loadouts`（配裝）
