using examples;
using lib.remnant2.saves.Model;
using lib.remnant2.saves.Model.Properties;
using lib.remnant2.saves.Navigation;

// R2Engrams: 把 Remnant 2 六個隱藏職業的 engram 材料塞進所有角色背包，
// 並確保 Lumenite Crystal / Scrap 足夠到 Wallace 合成。
// 用法: R2Engrams <profile.sav 路徑> <輸出路徑>   （加 --check 只檢查不寫入）

string srcPath = args.Length > 0 ? args[0] : throw new ArgumentException("需要 profile.sav 路徑");
string outPath = args.Length > 1 ? args[1] : "profile_new.sav";
bool checkOnly = args.Contains("--check");
// --items <清單檔> 模式: 每行 "ProfileId\t標籤\tequip|material\t數量(material 用)"，加完清單即結束
int itemsFlag = Array.IndexOf(args, "--items");
string? itemsFile = itemsFlag >= 0 && itemsFlag + 1 < args.Length ? args[itemsFlag + 1] : null;

var engramMaterials = new Dictionary<string, string>
{
    ["Alchemist 鍊金術師"] = "/Game/World_Base/Items/Materials/Engrams/Item_HiddenContainer_Material_Engram_Alchemist.Item_HiddenContainer_Material_Engram_Alchemist_C",
    ["Archon 執政官"] = "/Game/World_Base/Items/Materials/Engrams/Item_HiddenContainer_Material_Engram_Archon.Item_HiddenContainer_Material_Engram_Archon_C",
    ["Engineer 工程師"] = "/Game/World_Base/Items/Materials/Engrams/Item_HiddenContainer_Material_Engram_Engineer.Item_HiddenContainer_Material_Engram_Engineer_C",
    ["Explorer 探險家"] = "/Game/World_Base/Items/Materials/Engrams/Item_HiddenContainer_Material_Engram_Explorer.Item_HiddenContainer_Material_Engram_Explorer_C",
    ["Invader 侵入者"] = "/Game/World_Base/Items/Materials/Engrams/Item_HiddenContainer_Material_Engram_Invader.Item_HiddenContainer_Material_Engram_Invader_C",
    ["Summoner 召喚師"] = "/Game/World_Base/Items/Materials/Engrams/Item_HiddenContainer_Material_Engram_Summoner.Item_HiddenContainer_Material_Engram_Summoner_C",
};

const string scrapId = "/Game/World_Base/Items/Materials/Scraps/Material_Scraps.Material_Scraps_C";
const string lumeniteId = "/Game/World_Base/Items/Materials/LumeniteCrystal/Material_LumeniteCrystal.Material_LumeniteCrystal_C";

Console.WriteLine($"讀取 {srcPath} ...");
SaveFile sf = SaveFile.Read(srcPath);
Navigator navigator = new(sf);

List<ObjectProperty> characters = navigator.GetProperty("Characters")!.GetItems<ObjectProperty>();
Console.WriteLine($"共 {characters.Count} 個角色槽");

// --inspect <關鍵字>: 印出符合道具的完整結構（entry 欄位 + ItemBP UObject + InstanceData 屬性）
int inspFlag = Array.IndexOf(args, "--inspect");
if (inspFlag >= 0)
{
    string pat = args[inspFlag + 1];
    ObjectProperty ci = characters.First(c => c.Object != null);
    foreach (Property p in navigator.GetProperties("ItemBP", ci.Object!))
    {
        string cls = (p.Value as ObjectProperty)?.ClassName ?? "?";
        if (!cls.Contains(pat, StringComparison.OrdinalIgnoreCase)) continue;
        Console.WriteLine($"\n=== {cls} ===");
        PropertyBag bag = p.GetParent<PropertyBag>(navigator);
        foreach (var kv in bag.Properties)
        {
            if (kv.Key is "ItemBP" or "InstanceData")
            {
                UObject? o = (kv.Value.Value as ObjectProperty)?.Object;
                Console.WriteLine($"  {kv.Key}: idx={(kv.Value.Value as ObjectProperty)?.ObjectIndex}");
                if (o != null)
                {
                    Console.WriteLine($"    ObjectPath={o.ObjectPath}");
                    Console.WriteLine($"    WasLoadedByte={o.WasLoadedByte} IsActor={o.IsActor} ExtraLen={o.ExtraPropertiesData?.Length ?? -1} HasLoadedData={o.LoadedData != null} LoadedName={o.LoadedData?.Name?.Name} OuterId={o.LoadedData?.OuterId}");
                    Console.WriteLine($"    Components={(o.Components == null ? "null" : o.Components.Count.ToString())}");
                    if (o.Properties != null)
                        foreach (var ip in o.Properties.Properties)
                            PrintProp(ip.Key, ip.Value, "    ");
                    else Console.WriteLine("    Properties=null");
                }
            }
            else
                Console.WriteLine($"  {kv.Key} ({kv.Value.Type?.Name}) = {kv.Value.Value}");
        }
    }
    return;
}

// --fix-weapons: 把槍類道具的空 EquipmentInstanceData 就地轉成 RangedWeaponInstanceData(AmmoInClip+Level)
if (args.Contains("--fix-weapons"))
{
    // 可選: --fix-weapons 之後接遠程武器清單檔（絕對路徑逐行），沒給就用路徑判斷
    int fwIdx = Array.IndexOf(args, "--fix-weapons");
    HashSet<string>? rangedList = fwIdx + 1 < args.Length && File.Exists(args[fwIdx + 1])
        ? File.ReadLines(args[fwIdx + 1]).Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Trim())
            .ToHashSet(StringComparer.OrdinalIgnoreCase)
        : null;

    ObjectProperty cf = characters.First(c => c.Object != null);
    Property anchorP = navigator.GetProperties("ItemBP", cf.Object!).First();
    SaveData sd = anchorP.EnclosingSaveData(navigator);
    int fixedCount = 0;
    foreach (Property p in navigator.GetProperties("ItemBP", cf.Object!))
    {
        string cls = (p.Value as ObjectProperty)?.ClassName ?? "";
        bool isGun = rangedList != null
            ? rangedList.Contains(cls)
            : cls.Contains("/Weapons/LongGuns/", StringComparison.OrdinalIgnoreCase)
              || cls.Contains("/Weapons/HandGuns/", StringComparison.OrdinalIgnoreCase);
        if (!isGun) continue;
        UObject? inst = ((p.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty))?.Object;
        if (inst == null || !inst.ObjectPath!.EndsWith(".EquipmentInstanceData")) continue;

        inst.ObjectPath = "/Script/GunfireRuntime.RangedWeaponInstanceData";
        inst.LoadedData!.Name = sd.MakeFName("RangedWeaponInstanceData");
        if (!inst.Properties!.Properties.Any(x => x.Key == "AmmoInClip"))
            inst.Properties.Properties.Add(new("AmmoInClip", new Property
            {
                Name = sd.MakeFName("AmmoInClip"), Type = sd.MakeFName("IntProperty"),
                Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = 10000
            }));
        if (!inst.Properties.Properties.Any(x => x.Key == "Level"))
            inst.Properties.Properties.Add(new("Level", new Property
            {
                Name = sd.MakeFName("Level"), Type = sd.MakeFName("ByteProperty"),
                Index = 0, Size = 1, HasPropertyGuid = 0, PropertyGuid = null,
                Value = new lib.remnant2.saves.Model.Properties.ByteProperty
                {
                    EnumName = sd.MakeFName("None"), HasPropertyGuid = 0, PropertyGuid = null,
                    EnumByte = 1, EnumValue = null
                }
            }));
        inst.Properties.RefreshLookup();
        fixedCount++;
        Console.WriteLine($"  修正: {cls.Split('/').Last().Split('.').First()}");
    }
    Console.WriteLine($"共修正 {fixedCount} 把槍");
    if (fixedCount > 0)
    {
        Console.WriteLine($"寫入 {outPath} ...");
        SaveFile.Write(outPath, sf);
        SaveFile v2 = SaveFile.Read(outPath);
        Navigator nv2 = new(v2);
        ObjectProperty c2 = nv2.GetProperty("Characters")!.GetItems<ObjectProperty>().First(c => c.Object != null);
        int stillBad = nv2.GetProperties("ItemBP", c2.Object!).Count(x =>
        {
            string c = (x.Value as ObjectProperty)?.ClassName ?? "";
            bool gun = c.Contains("/Weapons/LongGuns/", StringComparison.OrdinalIgnoreCase) || c.Contains("/Weapons/HandGuns/", StringComparison.OrdinalIgnoreCase);
            UObject? i2 = ((x.GetParent<PropertyBag>(nv2)["InstanceData"].Value as ObjectProperty))?.Object;
            return gun && i2 != null && i2.ObjectPath!.EndsWith(".EquipmentInstanceData");
        });
        Console.WriteLine($"回讀驗證: 尚未修正的槍 = {stillBad} (應為 0)");
    }
    return;
}

// --fix-mods <對照檔>: 幫特殊槍補內建武器技能（EquipmentMods 結構，比照真實存檔的 Nightfall）
int modFlag = Array.IndexOf(args, "--fix-mods");
if (modFlag >= 0)
{
    var modMap = File.ReadLines(args[modFlag + 1])
        .Where(l => !string.IsNullOrWhiteSpace(l))
        .Select(l => l.Split('\t'))
        .ToDictionary(p => p[0], p => p[1], StringComparer.OrdinalIgnoreCase);

    ObjectProperty cm = characters.First(c => c.Object != null);
    Property anchorM = navigator.GetProperties("ItemBP", cm.Object!).First();
    SaveData sdm = anchorM.EnclosingSaveData(navigator);
    int modded = 0;

    foreach (Property p in navigator.GetProperties("ItemBP", cm.Object!))
    {
        string cls = (p.Value as ObjectProperty)?.ClassName ?? "";
        if (!modMap.TryGetValue(cls, out string? modPath)) continue;
        UObject? inst = ((p.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty))?.Object;
        if (inst?.Properties == null) continue;
        if (inst.Properties.Properties.Any(x => x.Key == "Mods")) continue; // 已有技能（真武器）

        // mod 的 UObject
        UObject modObj = new() { WasLoadedByte = 1, ObjectPath = modPath };
        sdm.Objects.Add(modObj);
        modObj.ObjectIndex = sdm.Objects.Count - 1;

        PropertyBag element = new()
        {
            Properties =
            [
                new("ModSlot", MakeByte(sdm, "ModSlot", 0)),
                new("Mod", new Property { Name = sdm.MakeFName("Mod"), Type = sdm.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = modObj.ObjectIndex } }),
                new("ModItemID", new Property { Name = sdm.MakeFName("ModItemID"), Type = sdm.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = -1 }),
                new("ModLevel", MakeByte(sdm, "ModLevel", 1)),
                new("HasSavedInstanceData", new Property { Name = sdm.MakeFName("HasSavedInstanceData"), Type = sdm.MakeFName("BoolProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = (byte)0 }),
                new("InstanceData", new Property { Name = sdm.MakeFName("InstanceData"), Type = sdm.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = -1 } }),
            ]
        };
        element.RefreshLookup();

        ArrayStructProperty arr = new()
        {
            HasPropertyGuid = 0, PropertyGuid = null,
            OuterElementType = sdm.MakeFName("StructProperty"),
            NameIndex = sdm.MakeFName("Mods").Index,
            TypeIndex = sdm.MakeFName("StructProperty").Index,
            Size = 0, Index = 0, Count = 1,
            ElementType = sdm.MakeFName("EquipmentModData"),
            Guid = new(), InnerHasPropertyGuid = 0, InnerPropertyGuid = null,
            Items = [element]
        };

        PropertyBag innerBag = new()
        {
            Properties = [new("Mods", new Property { Name = sdm.MakeFName("Mods"), Type = sdm.MakeFName("ArrayProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = arr })]
        };
        innerBag.RefreshLookup();

        lib.remnant2.saves.Model.Properties.StructProperty outerStruct = new()
        {
            Type = sdm.MakeFName("EquipmentMods"), Guid = new(), HasPropertyGuid = 0, PropertyGuid = null, Value = innerBag
        };
        Property modsProp = new() { Name = sdm.MakeFName("Mods"), Type = sdm.MakeFName("StructProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = outerStruct };

        int levelIdx = inst.Properties.Properties.FindIndex(x => x.Key == "Level");
        inst.Properties.Properties.Insert(levelIdx >= 0 ? levelIdx : inst.Properties.Properties.Count, new("Mods", modsProp));
        inst.Properties.RefreshLookup();
        modded++;
        Console.WriteLine($"  + 技能 {modPath.Split('/').Last().Split('.').First()} -> {cls.Split('/').Last().Split('.').First()}");
    }
    Console.WriteLine($"共補技能 {modded} 把");
    if (modded > 0)
    {
        Console.WriteLine($"寫入 {outPath} ...");
        SaveFile.Write(outPath, sf);
        Console.WriteLine("回讀驗證中 ...");
        SaveFile.Read(outPath);
        Console.WriteLine("驗證 OK");
    }
    return;

    static Property MakeByte(SaveData sd, string name, byte value) =>
        new() { Name = sd.MakeFName(name), Type = sd.MakeFName("ByteProperty"), Index = 0, Size = 1, HasPropertyGuid = 0, PropertyGuid = null,
                Value = new lib.remnant2.saves.Model.Properties.ByteProperty { EnumName = sd.MakeFName("None"), HasPropertyGuid = 0, PropertyGuid = null, EnumByte = value, EnumValue = null } };
}

// --repair-mods <mod_map> <ranged_list>: 校正每把遠程武器的內建技能——
// 引用錯的重指、該有沒有的補建、不該有的移除、正確的跳過
int repFlag = Array.IndexOf(args, "--repair-mods");
if (repFlag >= 0)
{
    var modMap = File.ReadLines(args[repFlag + 1])
        .Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Split('\t'))
        .ToDictionary(p => p[0], p => p[1], StringComparer.OrdinalIgnoreCase);
    HashSet<string> rangedSet = File.ReadLines(args[repFlag + 2])
        .Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Trim())
        .ToHashSet(StringComparer.OrdinalIgnoreCase);

    ObjectProperty cr = characters.First(c => c.Object != null);
    Property anchorR = navigator.GetProperties("ItemBP", cr.Object!).First();
    SaveData sdr = anchorR.EnclosingSaveData(navigator);
    int repaired = 0, removed = 0, created = 0, okCount = 0;

    foreach (Property p in navigator.GetProperties("ItemBP", cr.Object!))
    {
        string cls = (p.Value as ObjectProperty)?.ClassName ?? "";
        if (!rangedSet.Contains(cls)) continue;
        UObject? inst = ((p.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty))?.Object;
        if (inst?.Properties == null) continue;
        string shortName = cls.Split('/').Last().Split('.').First();
        bool hasMods = inst.Properties.Properties.Any(x => x.Key == "Mods");
        string? expected = modMap.TryGetValue(cls, out string? m) ? m : null;

        // 只看第一格（內建技能格）；後面的格位是玩家模組/突變器，絕不碰
        PropertyBag? firstEntry = null;
        if (hasMods)
        {
            var outerStruct = (lib.remnant2.saves.Model.Properties.StructProperty)inst.Properties["Mods"].Value!;
            var innerBag = (PropertyBag)outerStruct.Value!;
            var arr = (ArrayStructProperty)innerBag["Mods"].Value!;
            firstEntry = arr.Items.FirstOrDefault() as PropertyBag;
        }
        string firstPath = firstEntry != null && firstEntry.Contains("Mod")
            ? ((ObjectProperty)firstEntry["Mod"].Value!).ClassName ?? "" : "";

        if (expected == null)
        {
            // 無內建技能的槍：只在第一格是「別把槍的內建技能」（污染殘留）時才整組移除；
            // 玩家自己裝的一般模組路徑不在 builtin 集合裡，不會被誤刪
            if (hasMods && modMap.Values.Contains(firstPath, StringComparer.OrdinalIgnoreCase))
            {
                inst.Properties.Properties.RemoveAll(x => x.Key == "Mods");
                inst.Properties.RefreshLookup();
                removed++;
                Console.WriteLine($"  - 移除污染技能 {firstPath.Split('/').Last().Split('.').First()}: {shortName}");
            }
            else okCount++;
            continue;
        }

        if (!hasMods)
        {
            AddModsStruct(navigator, sdr, inst, expected);
            created++;
            Console.WriteLine($"  + 補建技能 {expected.Split('/').Last().Split('.').First()} -> {shortName}");
            continue;
        }

        if (firstEntry != null && !string.Equals(firstPath, expected, StringComparison.OrdinalIgnoreCase))
        {
            UObject newObj = new() { WasLoadedByte = 1, ObjectPath = expected };
            sdr.Objects.Add(newObj);
            newObj.ObjectIndex = sdr.Objects.Count - 1;
            firstEntry["Mod"].Value = new ObjectProperty { ObjectIndex = newObj.ObjectIndex };
            repaired++;
            Console.WriteLine($"  ~ 重指技能 {expected.Split('/').Last().Split('.').First()} -> {shortName} (原: {firstPath.Split('/').Last().Split('.').First()})");
        }
        else okCount++;
    }
    Console.WriteLine($"重指 {repaired}, 補建 {created}, 移除 {removed}, 原本正確 {okCount}");
    if (repaired + created + removed > 0)
    {
        Console.WriteLine($"寫入 {outPath} ...");
        SaveFile.Write(outPath, sf);
        SaveFile.Read(outPath);
        Console.WriteLine("回讀驗證 OK");
    }
    return;
}

// --prism-xp <ProfileId 關鍵字> <xp>: 設定稜晶待升級經驗值（照官方 PrismSetExperience 範例）
int prismFlag = Array.IndexOf(args, "--prism-xp");
if (prismFlag >= 0)
{
    string prismKey = args[prismFlag + 1];
    float xp = float.Parse(args[prismFlag + 2]);
    ObjectProperty cp = characters.First(c => c.Object != null);
    Property? prismBp = navigator.GetProperties("ItemBP", cp.Object!)
        .FirstOrDefault(x => ((x.Value as ObjectProperty)?.ClassName ?? "").Contains(prismKey, StringComparison.OrdinalIgnoreCase));
    if (prismBp == null) { Console.WriteLine($"找不到稜晶 {prismKey}"); return; }
    Console.WriteLine($"稜晶: {(prismBp.Value as ObjectProperty)!.ClassName}");
    PropertyBag pin = (prismBp.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty)!.Object!.Properties!;
    SaveData psd = prismBp.EnclosingSaveData(navigator);
    if (pin.Contains("PendingExperience"))
    {
        Console.WriteLine($"PendingExperience {pin["PendingExperience"].Value} -> {xp}");
        pin["PendingExperience"].Value = xp;
    }
    else
    {
        pin.Properties.Add(new("PendingExperience", new Property
        {
            Name = psd.MakeFName("PendingExperience"), Type = psd.MakeFName("FloatProperty"),
            Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = xp
        }));
        pin.RefreshLookup();
        Console.WriteLine($"新建 PendingExperience = {xp}");
    }
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --build-loadouts: 在第 2/3 格寫入槍傷流 (Hunter+Gunslinger) 與不死坦 (Medic+Warden)
// 前提: 第 1 格已由遊戲存過（提供槽物件與範本結構），全程只引用現成物件、不造新物件
if (args.Contains("--build-loadouts"))
{
    var chars1 = navigator.GetObjects("SavedCharacter");
    Property lrec = navigator.GetProperty("LoadoutRecords", chars1[0]) ?? throw new InvalidOperationException("沒有 LoadoutRecords，請先在遊戲內存一次配裝");
    ArrayStructProperty lrArr = (ArrayStructProperty)lrec.Value!;
    PropertyBag bag0 = (PropertyBag)lrArr.Items[0]!;
    Property tmplProp = bag0["Entries"];
    ArrayStructProperty tmpl = (ArrayStructProperty)tmplProp.Value!;
    int templateObjIdx = ((ObjectProperty)bag0["Template"].Value!).ObjectIndex;
    Property displayNameProp = bag0["DisplayName"];
    SaveData sdl = lrec.EnclosingSaveData(navigator);

    // 槽名 -> 遊戲建立的槽物件 index；並收集範本的遺物區與特性區
    Dictionary<string, int> slotIdx = new();
    List<PropertyBag> relicEntries = [], traitEntries = [], armorEntries = [];
    foreach (object? it in tmpl.Items)
    {
        PropertyBag pb = (PropertyBag)it!;
        ObjectProperty so = (ObjectProperty)pb["Slot"].Value!;
        string key = (so.ClassName ?? "").Split(':').Last();
        slotIdx[key] = so.ObjectIndex;
        if (key == "LoadoutEquipmentSlot_4") relicEntries.Add(pb);
        if (key == "LoadoutTraitSlot_2") traitEntries.Add(pb);
        if (key is "LoadoutEquipmentSlot_13" or "LoadoutEquipmentSlot_14" or "LoadoutEquipmentSlot_15" or "LoadoutEquipmentSlot_16") armorEntries.Add(pb);
    }
    Console.WriteLine($"範本槽物件 {slotIdx.Count} 個, 遺物區 {relicEntries.Count} 筆, 特性區 {traitEntries.Count} 筆, 防具 {armorEntries.Count} 筆");

    PropertyBag MakeEntry(string slotKey, string itemClass, int level, int idx)
    {
        PropertyBag e = new()
        {
            Properties =
            [
                new("Level", new Property { Name = sdl.MakeFName("Level"), Type = sdl.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = level }),
                new("Index", new Property { Name = sdl.MakeFName("Index"), Type = sdl.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = idx }),
                new("ItemClass", new Property { Name = sdl.MakeFName("ItemClass"), Type = sdl.MakeFName("SoftObjectProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = itemClass }),
                new("Slot", new Property { Name = sdl.MakeFName("Slot"), Type = sdl.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = slotIdx[slotKey] } }),
            ]
        };
        e.RefreshLookup();
        return e;
    }

    PropertyBag CloneEntry(PropertyBag src)
    {
        PropertyBag e = new()
        {
            Properties = src.Properties.Select(kv =>
            {
                Property p = kv.Value;
                object? v = p.Value is ObjectProperty op ? new ObjectProperty { ObjectIndex = op.ObjectIndex } : p.Value;
                return new KeyValuePair<string, Property>(kv.Key, new Property { Name = p.Name, Type = p.Type, Index = p.Index, Size = p.Size, HasPropertyGuid = p.HasPropertyGuid, PropertyGuid = p.PropertyGuid, Value = v });
            }).ToList()
        };
        e.RefreshLookup();
        return e;
    }

    PropertyBag MakeLoadout(List<PropertyBag> items)
    {
        ArrayStructProperty arr = new()
        {
            HasPropertyGuid = tmpl.HasPropertyGuid, PropertyGuid = tmpl.PropertyGuid,
            OuterElementType = tmpl.OuterElementType, NameIndex = tmpl.NameIndex, TypeIndex = tmpl.TypeIndex,
            Size = 0, Index = tmpl.Index, Count = (uint)items.Count,
            ElementType = tmpl.ElementType, Guid = tmpl.Guid,
            InnerHasPropertyGuid = tmpl.InnerHasPropertyGuid, InnerPropertyGuid = tmpl.InnerPropertyGuid,
            Items = [.. items]
        };
        PropertyBag rec = new()
        {
            Properties =
            [
                new("Template", new Property { Name = bag0["Template"].Name, Type = bag0["Template"].Type, Index = 0, Size = 4, HasPropertyGuid = bag0["Template"].HasPropertyGuid, PropertyGuid = bag0["Template"].PropertyGuid, Value = new ObjectProperty { ObjectIndex = templateObjIdx } }),
                new("Entries", new Property { Name = tmplProp.Name, Type = tmplProp.Type, Index = 0, Size = 0, HasPropertyGuid = tmplProp.HasPropertyGuid, PropertyGuid = tmplProp.PropertyGuid, Value = arr }),
                new("DisplayName", new Property { Name = displayNameProp.Name, Type = displayNameProp.Type, Index = 0, Size = displayNameProp.Size, HasPropertyGuid = displayNameProp.HasPropertyGuid, PropertyGuid = displayNameProp.PropertyGuid, Value = displayNameProp.Value }),
            ]
        };
        rec.RefreshLookup();
        return rec;
    }

    // ===== 第 2 格: 槍傷流 Hunter + Gunslinger =====
    List<PropertyBag> gun =
    [
        MakeEntry("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Hunter/Archetype_Hunter.Archetype_Hunter_C", 10, -1),
        MakeEntry("LoadoutTraitSlot_1", "/Game/World_Base/Items/Archetypes/Gunslinger/Archetype_Gunslinger.Archetype_Gunslinger_C", 1, -1),
        MakeEntry("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Nightfall/Weapon_Nightfall.Weapon_Nightfall_C", 10, -1),
        MakeEntry("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Nightfall/Mod_Dreadwalker/Mod_Dreadwalker.Mod_Dreadwalker_C", 1, 0),
        MakeEntry("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Enigma/Weapon_Enigma.Weapon_Enigma_C", 10, -1),
        MakeEntry("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Enigma/Mod_ChaosDriver/Mod_ChaosDriver.Mod_ChaosDriver_C", 1, 0),
        MakeEntry("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Weapons/Melee/Special/Stonebreaker/Weapon_Stonebreaker.Weapon_Stonebreaker_C", 10, -1),
        MakeEntry("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Hunter/Skills/HuntersMark/Skill_HuntersMark.Skill_HuntersMark_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_6", "/Game/World_Base/Items/Archetypes/Gunslinger/Skills/Bulletstorm/Skill_Bulletstorm.Skill_Bulletstorm_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_12", "/Game/World_Labyrinth/Items/Trinkets/Amulets/GunfireSecurityLanyard/Amulet_GunfireSecurityLanyard.Amulet_GunfireSecurityLanyard_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_8", "/Game/World_Root/Items/Trinkets/Rings/ProbabilityCord/Ring_ProbabilityCord.Ring_ProbabilityCord_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_9", "/Game/World_Root/Items/Trinkets/Rings/ZaniasMalice/Ring_ZaniasMalice.Ring_ZaniasMalice_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_10", "/Game/World_Root/Items/Trinkets/Rings/DeadKingsMemento/Ring_DeadKingsMemento.Ring_DeadKingsMemento_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_11", "/Game/World_Jungle/Items/Trinkets/Rings/StoneofBalance/Ring_StoneOfBalance.Ring_StoneOfBalance_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Hunter/Engram_Hunter.Engram_Hunter_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_3", "/Game/World_Base/Items/Archetypes/Gunslinger/Engram_Gunslinger.Engram_Gunslinger_C", 0, -1),
    ];
    gun.AddRange(relicEntries.Select(CloneEntry));
    gun.AddRange(armorEntries.Select(CloneEntry));
    gun.AddRange(traitEntries.Select(CloneEntry));

    // ===== 第 3 格: 不死坦 Medic + Warden =====
    List<PropertyBag> tank =
    [
        MakeEntry("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Medic/Archetype_Medic.Archetype_Medic_C", 10, -1),
        MakeEntry("LoadoutTraitSlot_1", "/Game/World_DLC3/Items/Archetypes/Warden/Archetype_Warden.Archetype_Warden_C", 1, -1),
        MakeEntry("LoadoutEquipmentSlot_0", "/Game/World_DLC3/Items/Weapons/Genesis/Weapon_Genesis.Weapon_Genesis_C", 10, -1),
        MakeEntry("LoadoutEquipmentSlot_0", "/Game/World_DLC3/Items/Weapons/Genesis/Mod_MegaDrive/Mod_MegaDrive.Mod_MegaDrive_C", 1, 0),
        MakeEntry("LoadoutEquipmentSlot_1", "/Game/World_DLC3/Items/Weapons/RepairTool/Weapon_RepairTool.Weapon_RepairTool_C", 10, -1),
        MakeEntry("LoadoutEquipmentSlot_7", "/Game/World_DLC1/Items/Weapons/Melee/Special/Wrathbringer/Weapon_Wrathbringer.Weapon_Wrathbringer_C", 10, -1),
        MakeEntry("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Medic/Skills/Wellspring/Skill_Wellspring.Skill_Wellspring_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_6", "/Game/World_DLC3/Items/Archetypes/Warden/Skills/ShieldDrone/Skill_SummonShieldDrone.Skill_SummonShieldDrone_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_12", "/Game/World_Jungle/Items/Trinkets/Amulets/FullMoonCirclet/Amulet_FullMoonCirclet.Amulet_FullMoonCirclet_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_8", "/Game/World_Fae/Items/Trinkets/Rings/RingOfGrace/Ring_RingOfGrace.Ring_RingOfGrace_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_9", "/Game/World_Jungle/Items/Trinkets/Rings/BurdenOfTheFollower/Ring_BurdenOfTheFollower.Ring_BurdenOfTheFollower_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_10", "/Game/World_Nerud/Items/Trinkets/Rings/ReroutingCable/Ring_ReroutingCable.Ring_ReroutingCable_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_11", "/Game/World_DLC3/Items/Trinkets/Rings/CombatShieldGenerator/Ring_CombatShieldGenerator.Ring_CombatShieldGenerator_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_13", "/Game/World_Base/Items/Armor/Leto2/Armor_Head_Leto2.Armor_Head_Leto2_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_14", "/Game/World_Base/Items/Armor/Leto2/Armor_Body_Leto2.Armor_Body_Leto2_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_15", "/Game/World_Base/Items/Armor/Leto2/Armor_Gloves_Leto2.Armor_Gloves_Leto2_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_16", "/Game/World_Base/Items/Armor/Leto2/Armor_Legs_Leto2.Armor_Legs_Leto2_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Medic/Engram_Medic.Engram_Medic_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_3", "/Game/World_DLC3/Items/Archetypes/Warden/Engram_Warden.Engram_Warden_C", 0, -1),
    ];
    tank.AddRange(relicEntries.Select(CloneEntry));
    tank.AddRange(traitEntries.Select(CloneEntry));

    // ===== 第 4 格: 火魔法師 Archon + Gunslinger（火風暴連發）=====
    List<PropertyBag> fire =
    [
        MakeEntry("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Archon/Archetype_Archon.Archetype_Archon_C", 1, -1),
        MakeEntry("LoadoutTraitSlot_1", "/Game/World_Base/Items/Archetypes/Gunslinger/Archetype_Gunslinger.Archetype_Gunslinger_C", 1, -1),
        MakeEntry("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Standard/TommyGun/Weapon_TommyGun.Weapon_TommyGun_C", 20, -1),
        MakeEntry("LoadoutEquipmentSlot_0", "/Game/World_Fae/Items/Mods/Mod_Firestorm/Mod_Firestorm.Mod_Firestorm_C", 0, 0),
        MakeEntry("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Hellfire/Weapon_Hellfire.Weapon_Hellfire_C", 10, -1),
        MakeEntry("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Hellfire/Mod_ExplosiveShot/Mod_ExplosiveShot.Mod_ExplosiveShot_C", 1, 0),
        MakeEntry("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Weapons/Melee/Special/Smolder/Weapon_Smolder.Weapon_Smolder_C", 10, -1),
        MakeEntry("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Archon/Skills/ChaosRune/Skill_ChaosGate.Skill_ChaosGate_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_6", "/Game/World_Base/Items/Archetypes/Gunslinger/Skills/Bulletstorm/Skill_Bulletstorm.Skill_Bulletstorm_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_12", "/Game/World_Jungle/Items/Trinkets/Amulets/TalismanOfTheSun/Amulet_TalismanOfTheSun.Amulet_TalismanOfTheSun_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_8", "/Game/World_Fae/Items/Trinkets/Rings/SingedRing/Ring_SingedRing.Ring_SingedRing_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_9", "/Game/World_Fae/Items/Trinkets/Rings/BurdenOfTheWarlock/Ring_BurdenOfTheWarlock.Ring_BurdenOfTheWarlock_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_10", "/Game/World_Root/Items/Trinkets/Rings/AnastasijasInspiration/Ring_AnastasijasInspiration.Ring_AnastasijasInspiration_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_11", "/Game/World_Jungle/Items/Trinkets/Rings/StoneofBalance/Ring_StoneOfBalance.Ring_StoneOfBalance_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Archon/Engram_Archon.Engram_Archon_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_3", "/Game/World_Base/Items/Archetypes/Gunslinger/Engram_Gunslinger.Engram_Gunslinger_C", 0, -1),
    ];
    fire.AddRange(relicEntries.Select(CloneEntry));
    fire.AddRange(armorEntries.Select(CloneEntry));
    fire.AddRange(traitEntries.Select(CloneEntry));

    // 內建技能對照表（武器 -> builtin mod），供武器條目自動附帶
    var wmodMap = File.ReadLines(@"D:\claude\tools\r2_engrams\mod_map.txt")
        .Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Split('\t'))
        .ToDictionary(p => p[0], p => p[1], StringComparer.OrdinalIgnoreCase);

    // 武器條目組（武器 + 內建技能 + 改裝）
    List<PropertyBag> Weapon(string slotKey, string wpath, int level, string? mutator)
    {
        List<PropertyBag> l = [MakeEntry(slotKey, wpath, level, -1)];
        if (wmodMap.TryGetValue(wpath, out string? bm)) l.Add(MakeEntry(slotKey, bm, 1, 0));
        if (mutator != null) l.Add(MakeEntry(slotKey, mutator, 0, 1));
        return l;
    }

    const string GEMS = "/Game/World_Base/Items/Gems";
    string MG(string sub) => $"{GEMS}/{sub}_C";

    // ===== 第 5 格: 森林守衛 Invoker + Ritualist（異常狀態）=====
    List<PropertyBag> forest =
    [
        MakeEntry("LoadoutTraitSlot_0", "/Game/World_DLC2/Items/Archetypes/Invoker/Archetype_Invoker.Archetype_Invoker_C", 1, -1),
        MakeEntry("LoadoutTraitSlot_1", "/Game/World_DLC1/Items/Archetypes/Ritualist/Archetype_Ritualist.Archetype_Ritualist_C", 1, -1),
        .. Weapon("LoadoutEquipmentSlot_0", "/Game/World_DLC1/Items/Weapons/Buster/Weapon_Sparkfire.Weapon_Sparkfire_C", 10, "/Game/World_DLC1/Items/Gems/Ranged/FetidWounds/MetaGem_FetidWounds.MetaGem_FetidWounds_C"),
        .. Weapon("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Nebula/Weapon_Nebula.Weapon_Nebula_C", 10, "/Game/World_DLC1/Items/Gems/Ranged/Maelstrom/MetaGem_Maelstrom.MetaGem_Maelstrom_C"),
        .. Weapon("LoadoutEquipmentSlot_7", "/Game/World_DLC1/Items/Weapons/Melee/Scythe/Scythe_Ritualist/Weapon_RitualistScythe.Weapon_RitualistScythe_C", 10, "/Game/World_DLC1/Items/Gems/Melee/TaintedBlade/MetaGem_TaintedBlade.MetaGem_TaintedBlade_C"),
        MakeEntry("LoadoutEquipmentSlot_5", "/Game/World_DLC2/Items/Archetypes/Invoker/Skills/WayOfForest/Skill_WayOfForest.Skill_WayOfForest_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_6", "/Game/World_DLC1/Items/Archetypes/Ritualist/Skills/Miasma/Skill_Miasma.Skill_Miasma_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_12", "/Game/World_DLC2/Items/Trinkets/Amulets/FragrantThorn/Amulet_FragrantThorn.Amulet_FragrantThorn_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_8", "/Game/World_Base/Items/Trinkets/Rings/DevouringLoop/Ring_DevouringLoop.Ring_DevouringLoop_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_9", "/Game/World_Base/Items/Trinkets/Rings/BraidedThorns/Ring_BraidedThorns.Ring_BraidedThorns_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_10", "/Game/World_Jungle/Items/Trinkets/Rings/Rotward/Ring_Rotward.Ring_Rotward_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_11", "/Game/World_Fae/Items/Trinkets/Rings/TimekeepersJewel/Ring_TimekeepersJewel.Ring_TimekeepersJewel_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_2", "/Game/World_DLC2/Items/Archetypes/Invoker/Engram/Engram_Invoker.Engram_Invoker_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_3", "/Game/World_DLC1/Items/Archetypes/Ritualist/Engram/Engram_Ritualist.Engram_Ritualist_C", 0, -1),
    ];
    forest.AddRange(relicEntries.Select(CloneEntry));
    forest.AddRange(armorEntries.Select(CloneEntry));
    forest.AddRange(traitEntries.Select(CloneEntry));

    // ===== 第 6 格: 出血獵弓 Hunter + Invader =====
    List<PropertyBag> bow =
    [
        MakeEntry("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Hunter/Archetype_Hunter.Archetype_Hunter_C", 10, -1),
        MakeEntry("LoadoutTraitSlot_1", "/Game/World_Base/Items/Archetypes/Invader/Archetype_Invader.Archetype_Invader_C", 1, -1),
        .. Weapon("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Sagittarius/Weapon_Sagittarius.Weapon_Sagittarius_C", 10, "/Game/World_Base/Items/Gems/Ranged/MetaGems/TwistingWounds/MetaGem_TwistingWounds.MetaGem_TwistingWounds_C"),
        .. Weapon("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Sorrow/Weapon_Sorrow.Weapon_Sorrow_C", 10, "/Game/World_Base/Items/Gems/Ranged/MetaGems/Supercharger/MetaGem_Supercharger.MetaGem_Supercharger_C"),
        .. Weapon("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Weapons/Melee/Special/SpectralBlade/Weapon_SpectralBlade.Weapon_SpectralBlade_C", 10, "/Game/World_Base/Items/Gems/Melee/MetaGems/Edgelord/MetaGem_Edgelord.MetaGem_Edgelord_C"),
        MakeEntry("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Hunter/Skills/HuntersShroud/Skill_HuntersShroud.Skill_HuntersShroud_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_6", "/Game/World_Base/Items/Archetypes/Invader/Skills/VoidCloak/Skill_VoidCloak.Skill_VoidCloak_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_12", "/Game/World_Jungle/Items/Trinkets/Amulets/RavagersMark/Amulet_RavagersMark.Amulet_RavagersMark_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_8", "/Game/World_Fae/Items/Trinkets/Rings/FaeHunterRing/Ring_FaeHunterRing.Ring_FaeHunterRing_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_9", "/Game/World_Root/Items/Trinkets/Rings/ZaniasMalice/Ring_ZaniasMalice.Ring_ZaniasMalice_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_10", "/Game/World_Root/Items/Trinkets/Rings/DeadKingsMemento/Ring_DeadKingsMemento.Ring_DeadKingsMemento_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_11", "/Game/World_Root/Items/Trinkets/Rings/ProbabilityCord/Ring_ProbabilityCord.Ring_ProbabilityCord_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Hunter/Engram_Hunter.Engram_Hunter_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_3", "/Game/World_Base/Items/Archetypes/Invader/Engram_Invader.Engram_Invader_C", 0, -1),
    ];
    bow.AddRange(relicEntries.Select(CloneEntry));
    bow.AddRange(armorEntries.Select(CloneEntry));
    bow.AddRange(traitEntries.Select(CloneEntry));

    // ===== 第 7 格: 召喚掛機 Summoner + Engineer =====
    List<PropertyBag> summon =
    [
        MakeEntry("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Summoner/Archetype_Summoner.Archetype_Summoner_C", 10, -1),
        MakeEntry("LoadoutTraitSlot_1", "/Game/World_Base/Items/Archetypes/Engineer/Archetype_Engineer.Archetype_Engineer_C", 1, -1),
        .. Weapon("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Deceit/Weapon_Deceit.Weapon_Deceit_C", 10, "/Game/World_Base/Items/Gems/Ranged/MetaGems/Refunder/MetaGem_Refunder.MetaGem_Refunder_C"),
        .. Weapon("LoadoutEquipmentSlot_1", "/Game/World_DLC1/Items/Weapons/Anguish/Weapon_Anguish.Weapon_Anguish_C", 10, "/Game/World_Base/Items/Gems/Ranged/MetaGems/GhostShell/MetaGem_GhostShell.MetaGem_GhostShell_C"),
        .. Weapon("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Weapons/Melee/Special/LabyrinthStaff/Weapon_LabyrinthStaff.Weapon_LabyrinthStaff_C", 10, "/Game/World_Base/Items/Gems/Melee/MetaGems/ShieldBreaker/MetaGem_ShieldBreaker.MetaGem_ShieldBreaker_C"),
        MakeEntry("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Summoner/Skills/MinionFlyer/Skill_SummonFlyerMinion.Skill_SummonFlyerMinion_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_6", "/Game/World_Base/Items/Archetypes/Engineer/Skills/Skill_Gatling/Skill_Deployable_Gatling.Skill_Deployable_Gatling_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_12", "/Game/World_Fae/Items/Trinkets/Amulets/SilverRibbon/Amulet_SilverRibbon.Amulet_SilverRibbon_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_8", "/Game/World_Jungle/Items/Trinkets/Rings/SoulLink/Ring_SoulLink.Ring_SoulLink_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_9", "/Game/World_Jungle/Items/Trinkets/Rings/BurdenOfTheFollower/Ring_BurdenOfTheFollower.Ring_BurdenOfTheFollower_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_10", "/Game/World_Jungle/Items/Trinkets/Rings/Rotward/Ring_Rotward.Ring_Rotward_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_11", "/Game/World_Fae/Items/Trinkets/Rings/RingOfGrace/Ring_RingOfGrace.Ring_RingOfGrace_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Summoner/Engram_Summoner.Engram_Summoner_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_3", "/Game/World_Base/Items/Archetypes/Engineer/Engram_Engineer.Engram_Engineer_C", 0, -1),
    ];
    summon.AddRange(relicEntries.Select(CloneEntry));
    summon.AddRange(armorEntries.Select(CloneEntry));
    summon.AddRange(traitEntries.Select(CloneEntry));

    // ===== 第 8 格: 團隊奶媽 Handler + Medic =====
    List<PropertyBag> nanny =
    [
        MakeEntry("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Handler/Archetype_Handler.Archetype_Handler_C", 10, -1),
        MakeEntry("LoadoutTraitSlot_1", "/Game/World_Base/Items/Archetypes/Medic/Archetype_Medic.Archetype_Medic_C", 10, -1),
        .. Weapon("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/CrescentMoon/Weapon_CrescentMoon.Weapon_CrescentMoon_C", 10, "/Game/World_Base/Items/Gems/Ranged/MetaGems/SpiritHealer/MetaGem_SpiritHealer.MetaGem_SpiritHealer_C"),
        .. Weapon("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Sorrow/Weapon_Sorrow.Weapon_Sorrow_C", 10, "/Game/World_Base/Items/Gems/Ranged/MetaGems/Failsafe/MetaGem_Failsafe.MetaGem_Failsafe_C"),
        .. Weapon("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Weapons/Melee/Special/RedDoeStaff/Weapon_RedDoeStaff.Weapon_RedDoeStaff_C", 10, "/Game/World_Base/Items/Gems/Melee/MetaGems/Transferrence/MetaGem_Transference.MetaGem_Transference_C"),
        MakeEntry("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Handler/Skills/Skill_SupportDog/Skill_SupportDog_Command.Skill_SupportDog_Command_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_6", "/Game/World_Base/Items/Archetypes/Medic/Skills/Redemption/Skill_Redemption.Skill_Redemption_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_12", "/Game/World_Fae/Items/Trinkets/Amulets/NimuesRibbon/Amulet_NimuesRibbon.Amulet_NimuesRibbon_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_8", "/Game/World_Base/Items/Trinkets/Rings/BlessedRing/Ring_BlessedRing.Ring_BlessedRing_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_9", "/Game/World_Fae/Items/Trinkets/Rings/BurdenOfTheDivine/Ring_BurdenOfTheDivine.Ring_BurdenOfTheDivine_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_10", "/Game/World_Fae/Items/Trinkets/Rings/RingOfGrace/Ring_RingOfGrace.Ring_RingOfGrace_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_11", "/Game/World_Fae/Items/Trinkets/Rings/FaeProtectorSignet/Ring_FaeProtectorSignet.Ring_FaeProtectorSignet_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Handler/Engram_Handler.Engram_Handler_C", 0, -1),
        MakeEntry("LoadoutEquipmentSlot_3", "/Game/World_Base/Items/Archetypes/Medic/Engram_Medic.Engram_Medic_C", 0, -1),
    ];
    nanny.AddRange(relicEntries.Select(CloneEntry));
    nanny.AddRange(armorEntries.Select(CloneEntry));
    nanny.AddRange(traitEntries.Select(CloneEntry));

    // ===== 回頭幫第 2/3/4 格掛改裝（缺才補）=====
    (int li, string slot, string mutator)[] retrofits =
    [
        (1, "LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Gems/Ranged/MetaGems/Momentum/MetaGem_Momentum.MetaGem_Momentum_C"),
        (1, "LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Gems/Ranged/MetaGems/Harmonizer/MetaGem_Harmonizer.MetaGem_Harmonizer_C"),
        (1, "LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Gems/Melee/MetaGems/WeaponLord/MetaGem_WeaponLord.MetaGem_WeaponLord_C"),
        (2, "LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Gems/Ranged/MetaGems/Timewave/MetaGem_Timewave.MetaGem_Timewave_C"),
        (2, "LoadoutEquipmentSlot_1", "/Game/World_DLC3/Items/Gems/Ranged/Insulator/MetaGem_Insulator.MetaGem_Insulator_C"),
        (2, "LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Gems/Melee/MetaGems/VampireBlade/MetaGem_VampireBlade.MetaGem_VampireBlade_C"),
        (3, "LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Gems/Ranged/MetaGems/Bandit/MetaGem_Bandit.MetaGem_Bandit_C"),
        (3, "LoadoutEquipmentSlot_1", "/Game/World_DLC2/Items/Gems/Ranged/SearingWounds/MetaGem_SearingWounds.MetaGem_SearingWounds_C"),
        (3, "LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Gems/Melee/MetaGems/Dervish/MetaGem_Dervish.MetaGem_Dervish_C"),
    ];
    int retroAdded = 0;
    foreach ((int li, string slot, string mutator) in retrofits)
    {
        if (lrArr.Items.Count <= li) continue;
        PropertyBag rb = (PropertyBag)lrArr.Items[li]!;
        ArrayStructProperty ra = (ArrayStructProperty)rb["Entries"].Value!;
        int sIdx = slotIdx[slot];
        bool hasMut = ra.Items.Cast<PropertyBag>().Any(e =>
            ((ObjectProperty)e["Slot"].Value!).ObjectIndex == sIdx && e.Contains("Index") && (int)e["Index"].Value! == 1);
        if (hasMut) continue;
        ra.Items.Add(MakeEntry(slot, mutator, 0, 1));
        retroAdded++;
    }
    Console.WriteLine($"回補改裝 {retroAdded} 筆");

    // 將四套新 build 填入「空格」（遊戲已把結構展開成 10 格 + 快照）
    int filled = 0;
    var queue = new Queue<(string name, List<PropertyBag> items)>([("森林守衛", forest), ("出血獵弓", bow), ("召喚掛機", summon), ("團隊奶媽", nanny)]);
    for (int si = 0; si < lrArr.Items.Count && queue.Count > 0; si++)
    {
        PropertyBag rbag = (PropertyBag)lrArr.Items[si]!;
        if (!rbag.Contains("Entries")) continue;
        ArrayStructProperty ea = (ArrayStructProperty)rbag["Entries"].Value!;
        if (ea.Items.Count > 0) continue;
        (string name, List<PropertyBag> items) = queue.Dequeue();
        foreach (PropertyBag it in items) ea.Items.Add(it);
        Console.WriteLine($"[格 {si}] 填入 {name} ({items.Count} 筆)");
        filled++;
    }
    if (filled == 0 && retroAdded == 0) { Console.WriteLine("無空格可填且無需回補，不寫入"); return; }
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --fix-melee-mutators: 配裝中近戰(Slot_7)的突變因子 Index 1 -> 0（近戰無模組槽）
if (args.Contains("--fix-melee-mutators"))
{
    var charsm = navigator.GetObjects("SavedCharacter");
    Property lrm = navigator.GetProperty("LoadoutRecords", charsm[0])!;
    ArrayStructProperty lram = (ArrayStructProperty)lrm.Value!;
    int fixedM = 0;
    for (int li = 0; li < lram.Items.Count; li++)
    {
        PropertyBag rb = (PropertyBag)lram.Items[li]!;
        if (!rb.Contains("Entries")) continue;
        ArrayStructProperty ea = (ArrayStructProperty)rb["Entries"].Value!;
        foreach (object? it in ea.Items)
        {
            if (it is not PropertyBag e || !e.Contains("Slot") || !e.Contains("Index")) continue;
            string slotCls = ((ObjectProperty)e["Slot"].Value!).ClassName ?? "";
            if (!slotCls.EndsWith("LoadoutEquipmentSlot_7")) continue;
            if ((int)e["Index"].Value! != 1) continue;
            e["Index"].Value = 0;
            fixedM++;
            Console.WriteLine($"  [格 {li}] 近戰突變因子 Index 1->0: {((e["ItemClass"].Value as string) ?? "").Split('/').Last().Split('.').First()}");
        }
    }
    Console.WriteLine($"共修正 {fixedM} 筆");
    if (fixedM == 0) return;
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --refit: (1) 第 6/7 格(index 5,6)換成無限夜幕/一擊必殺 (2) 各 build 配專屬防具
if (args.Contains("--refit"))
{
    var charsr = navigator.GetObjects("SavedCharacter");
    Property lrr = navigator.GetProperty("LoadoutRecords", charsr[0])!;
    ArrayStructProperty lrar = (ArrayStructProperty)lrr.Value!;
    PropertyBag recT = (PropertyBag)lrar.Items[0]!;
    ArrayStructProperty entT = (ArrayStructProperty)recT["Entries"].Value!;
    SaveData sdr2 = lrr.EnclosingSaveData(navigator);

    Dictionary<string, int> smap = new();
    List<PropertyBag> relicT = [], traitT = [];
    foreach (object? it in entT.Items)
    {
        PropertyBag pb = (PropertyBag)it!;
        ObjectProperty so = (ObjectProperty)pb["Slot"].Value!;
        string key = (so.ClassName ?? "").Split(':').Last();
        smap[key] = so.ObjectIndex;
        if (key == "LoadoutEquipmentSlot_4") relicT.Add(pb);
        if (key == "LoadoutTraitSlot_2") traitT.Add(pb);
    }

    PropertyBag E(string slotKey, string cls, int level, int idx)
    {
        PropertyBag e = new()
        {
            Properties =
            [
                new("Level", new Property { Name = sdr2.MakeFName("Level"), Type = sdr2.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = level }),
                new("Index", new Property { Name = sdr2.MakeFName("Index"), Type = sdr2.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = idx }),
                new("ItemClass", new Property { Name = sdr2.MakeFName("ItemClass"), Type = sdr2.MakeFName("SoftObjectProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = cls }),
                new("Slot", new Property { Name = sdr2.MakeFName("Slot"), Type = sdr2.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = smap[slotKey] } }),
            ]
        };
        e.RefreshLookup();
        return e;
    }

    PropertyBag Clone2(PropertyBag src)
    {
        PropertyBag c = new()
        {
            Properties = src.Properties.Select(kv =>
            {
                Property p = kv.Value;
                object? v = p.Value is ObjectProperty op ? new ObjectProperty { ObjectIndex = op.ObjectIndex } : p.Value;
                return new KeyValuePair<string, Property>(kv.Key, new Property { Name = p.Name, Type = p.Type, Index = p.Index, Size = p.Size, HasPropertyGuid = p.HasPropertyGuid, PropertyGuid = p.PropertyGuid, Value = v });
            }).ToList()
        };
        c.RefreshLookup();
        return c;
    }

    List<PropertyBag> Armor4(string set, string folder) =>
    [
        E("LoadoutEquipmentSlot_13", $"{folder}/Armor_Head_{set}.Armor_Head_{set}_C", 0, -1),
        E("LoadoutEquipmentSlot_14", $"{folder}/Armor_Body_{set}.Armor_Body_{set}_C", 0, -1),
        E("LoadoutEquipmentSlot_15", $"{folder}/Armor_Gloves_{set}.Armor_Gloves_{set}_C", 0, -1),
        E("LoadoutEquipmentSlot_16", $"{folder}/Armor_Legs_{set}.Armor_Legs_{set}_C", 0, -1),
    ];

    // ===== 第 6 格 (index 5): 無限夜幕 Hunter + Archon =====
    List<PropertyBag> nightfall =
    [
        E("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Hunter/Archetype_Hunter.Archetype_Hunter_C", 10, -1),
        E("LoadoutTraitSlot_1", "/Game/World_Base/Items/Archetypes/Archon/Archetype_Archon.Archetype_Archon_C", 1, -1),
        E("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Nightfall/Weapon_Nightfall.Weapon_Nightfall_C", 10, -1),
        E("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Nightfall/Mod_Dreadwalker/Mod_Dreadwalker.Mod_Dreadwalker_C", 1, 0),
        E("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Gems/Ranged/MetaGems/DeadlyCalm/MetaGem_DeadlyCalm.MetaGem_DeadlyCalm_C", 0, 1),
        E("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Enigma/Weapon_Enigma.Weapon_Enigma_C", 10, -1),
        E("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Enigma/Mod_ChaosDriver/Mod_ChaosDriver.Mod_ChaosDriver_C", 1, 0),
        E("LoadoutEquipmentSlot_1", "/Game/World_DLC2/Items/Gems/Ranged/Spellweaver/MetaGem_Spellweaver.MetaGem_Spellweaver_C", 0, 1),
        E("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Weapons/Melee/Special/FeralJudgment/Weapon_FeralJudgment.Weapon_FeralJudgment_C", 10, -1),
        E("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Gems/Melee/MetaGems/Striker/MetaGem_Striker.MetaGem_Striker_C", 0, 0),
        E("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Hunter/Skills/HuntersFocus/Skill_HuntersFocus.Skill_HuntersFocus_C", 0, -1),
        E("LoadoutEquipmentSlot_6", "/Game/World_Base/Items/Archetypes/Archon/Skills/ChaosRune/Skill_ChaosGate.Skill_ChaosGate_C", 0, -1),
        E("LoadoutEquipmentSlot_12", "/Game/World_Root/Items/Trinkets/Amulets/AbrasiveWhetstone/Amulet_AbrasiveWhetstone.Amulet_AbrasiveWhetstone_C", 0, -1),
        E("LoadoutEquipmentSlot_8", "/Game/World_Fae/Items/Trinkets/Rings/FaerinsSigil/Ring_FaerinsSigil.Ring_FaerinsSigil_C", 0, -1),
        E("LoadoutEquipmentSlot_9", "/Game/World_Fae/Items/Trinkets/Rings/StoneOfMalevolence/Ring_StoneOfMalevolence.Ring_StoneOfMalevolence_C", 0, -1),
        E("LoadoutEquipmentSlot_10", "/Game/World_Root/Items/Trinkets/Rings/ProbabilityCord/Ring_ProbabilityCord.Ring_ProbabilityCord_C", 0, -1),
        E("LoadoutEquipmentSlot_11", "/Game/World_Root/Items/Trinkets/Rings/ZaniasMalice/Ring_ZaniasMalice.Ring_ZaniasMalice_C", 0, -1),
        E("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Hunter/Engram_Hunter.Engram_Hunter_C", 0, -1),
        E("LoadoutEquipmentSlot_3", "/Game/World_Base/Items/Archetypes/Archon/Engram_Archon.Engram_Archon_C", 0, -1),
        .. Armor4("Cultist", "/Game/World_Base/Items/Armor/Remnant1/Cultist"),
    ];
    nightfall.AddRange(relicT.Select(Clone2));
    nightfall.AddRange(traitT.Select(Clone2));

    // ===== 第 7 格 (index 6): 一擊必殺孢子槍 Invader + Challenger =====
    List<PropertyBag> oneshot =
    [
        E("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Invader/Archetype_Invader.Archetype_Invader_C", 1, -1),
        E("LoadoutTraitSlot_1", "/Game/World_Base/Items/Archetypes/Challenger/Archetype_Challenger.Archetype_Challenger_C", 10, -1),
        E("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Sporebloom/Weapon_Sporebloom.Weapon_Sporebloom_C", 10, -1),
        E("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Sporebloom/Mod_SporeShot/Mod_SporeShot.Mod_SporeShot_C", 1, 0),
        E("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Gems/Ranged/MetaGems/Slayer/MetaGem_Slayer.MetaGem_Slayer_C", 0, 1),
        E("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/CubeGun/Weapon_CubeGun.Weapon_CubeGun_C", 10, -1),
        E("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/CubeGun/Mod_CubeShield/Mod_CubeShield.Mod_CubeShield_C", 1, 0),
        E("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Gems/Ranged/MetaGems/KillSwitch/MetaGem_KillSwitch.MetaGem_KillSwitch_C", 0, 1),
        E("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Weapons/Melee/Special/WorldsEdge/Weapon_WorldsEdge.Weapon_WorldsEdge_C", 10, -1),
        E("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Gems/Melee/MetaGems/Edgelord/MetaGem_Edgelord.MetaGem_Edgelord_C", 0, 0),
        E("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Invader/Skills/WormHole/Skill_WormHole.Skill_WormHole_C", 0, -1),
        E("LoadoutEquipmentSlot_6", "/Game/World_Base/Items/Archetypes/Challenger/Skills/WarStomp/Skill_WarStomp.Skill_WarStomp_C", 0, -1),
        E("LoadoutEquipmentSlot_12", "/Game/World_Root/Items/Trinkets/Amulets/AnkhOfPower/Amulet_AnkhOfPower.Amulet_AnkhOfPower_C", 0, -1),
        E("LoadoutEquipmentSlot_8", "/Game/World_Root/Items/Trinkets/Rings/BurdenOfTheDestroyer/Ring_BurdenOfTheDestroyer.Ring_BurdenOfTheDestroyer_C", 0, -1),
        E("LoadoutEquipmentSlot_9", "/Game/World_Nerud/Items/Trinkets/Rings/PointFocusRing/Ring_PointFocusRing.Ring_PointFocusRing_C", 0, -1),
        E("LoadoutEquipmentSlot_10", "/Game/World_Jungle/Items/Trinkets/Rings/StoneofBalance/Ring_StoneOfBalance.Ring_StoneOfBalance_C", 0, -1),
        E("LoadoutEquipmentSlot_11", "/Game/World_Root/Items/Trinkets/Rings/DeadKingsMemento/Ring_DeadKingsMemento.Ring_DeadKingsMemento_C", 0, -1),
        E("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Invader/Engram_Invader.Engram_Invader_C", 0, -1),
        E("LoadoutEquipmentSlot_3", "/Game/World_Base/Items/Archetypes/Challenger/Engram_Challenger.Engram_Challenger_C", 0, -1),
        .. Armor4("Void", "/Game/World_Base/Items/Armor/Remnant1/Void"),
    ];
    oneshot.AddRange(relicT.Select(Clone2));
    oneshot.AddRange(traitT.Select(Clone2));

    void ReplaceSlot(int idx, List<PropertyBag> items, string name)
    {
        PropertyBag rb = (PropertyBag)lrar.Items[idx]!;
        ArrayStructProperty ea = (ArrayStructProperty)rb["Entries"].Value!;
        ea.Items.Clear();
        foreach (PropertyBag e in items) ea.Items.Add(e);
        Console.WriteLine($"[格 {idx}] 覆蓋為 {name} ({items.Count} 筆)");
    }
    ReplaceSlot(5, nightfall, "無限夜幕");
    ReplaceSlot(6, oneshot, "一擊必殺孢子槍");

    // 各 build 重配專屬防具
    (int idx, string set, string folder)[] armors =
    [
        (1, "Gunslinger", "/Game/World_Base/Items/Armor/Archetype/Gunslinger"),
        (3, "Archon", "/Game/World_Base/Items/Armor/Archetype/Arcanist"),
        (4, "Elder", "/Game/World_Base/Items/Armor/Remnant1/Elder"),
        (7, "Medic", "/Game/World_Base/Items/Armor/Archetype_Starting/Medic"),
    ];
    foreach ((int idx, string set, string folder) in armors)
    {
        PropertyBag rb = (PropertyBag)lrar.Items[idx]!;
        ArrayStructProperty ea = (ArrayStructProperty)rb["Entries"].Value!;
        HashSet<int> armorSlots = [smap["LoadoutEquipmentSlot_13"], smap["LoadoutEquipmentSlot_14"], smap["LoadoutEquipmentSlot_15"], smap["LoadoutEquipmentSlot_16"]];
        int removed = ((List<object?>)ea.Items).RemoveAll(x => x is PropertyBag e && armorSlots.Contains(((ObjectProperty)e["Slot"].Value!).ObjectIndex));
        foreach (PropertyBag e in Armor4(set, folder)) ea.Items.Add(e);
        Console.WriteLine($"[格 {idx}] 防具換成 {set} 套裝 (移除舊 {removed} 件)");
    }

    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --melee-slot1: 把第 1 格（index 0）覆蓋為最強近戰 build（Challenger+Handler 直升機流）
if (args.Contains("--melee-slot1"))
{
    var charsx = navigator.GetObjects("SavedCharacter");
    Property lrx = navigator.GetProperty("LoadoutRecords", charsx[0])!;
    ArrayStructProperty lrax = (ArrayStructProperty)lrx.Value!;
    PropertyBag rec0 = (PropertyBag)lrax.Items[0]!;
    ArrayStructProperty ent0 = (ArrayStructProperty)rec0["Entries"].Value!;
    SaveData sdx = lrx.EnclosingSaveData(navigator);

    Dictionary<string, int> sm = new();
    List<PropertyBag> relicKeep = [], traitKeep = [];
    foreach (object? it in ent0.Items)
    {
        PropertyBag pb = (PropertyBag)it!;
        ObjectProperty so = (ObjectProperty)pb["Slot"].Value!;
        string key = (so.ClassName ?? "").Split(':').Last();
        sm[key] = so.ObjectIndex;
        if (key == "LoadoutEquipmentSlot_4") relicKeep.Add(pb);
        if (key == "LoadoutTraitSlot_2") traitKeep.Add(pb);
    }

    PropertyBag E(string slotKey, string cls, int level, int idx)
    {
        PropertyBag e = new()
        {
            Properties =
            [
                new("Level", new Property { Name = sdx.MakeFName("Level"), Type = sdx.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = level }),
                new("Index", new Property { Name = sdx.MakeFName("Index"), Type = sdx.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = idx }),
                new("ItemClass", new Property { Name = sdx.MakeFName("ItemClass"), Type = sdx.MakeFName("SoftObjectProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = cls }),
                new("Slot", new Property { Name = sdx.MakeFName("Slot"), Type = sdx.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = sm[slotKey] } }),
            ]
        };
        e.RefreshLookup();
        return e;
    }

    List<PropertyBag> melee =
    [
        E("LoadoutTraitSlot_0", "/Game/World_Base/Items/Archetypes/Challenger/Archetype_Challenger.Archetype_Challenger_C", 10, -1),
        E("LoadoutTraitSlot_1", "/Game/World_Base/Items/Archetypes/Handler/Archetype_Handler.Archetype_Handler_C", 10, -1),
        // 近戰主武器: 華麗連枷 + 超速(近戰爆擊疊層)
        E("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Weapons/Melee/Standard/Flail/OrnateFlail/Weapon_OrnateFlail.Weapon_OrnateFlail_C", 20, -1),
        E("LoadoutEquipmentSlot_7", "/Game/World_Base/Items/Gems/Melee/MetaGems/Overdrive/MetaGem_Overdrive.MetaGem_Overdrive_C", 0, 0),
        // 副武器: 孢子綻放(AoE 支援) + 子午線(榴彈)
        E("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Sporebloom/Weapon_Sporebloom.Weapon_Sporebloom_C", 10, -1),
        E("LoadoutEquipmentSlot_0", "/Game/World_Base/Items/Weapons/LongGuns/Special/Sporebloom/Mod_SporeShot/Mod_SporeShot.Mod_SporeShot_C", 1, 0),
        E("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Meridian/Weapon_Meridian.Weapon_Meridian_C", 10, -1),
        E("LoadoutEquipmentSlot_1", "/Game/World_Base/Items/Weapons/HandGuns/Special/Meridian/Mod_Screamer/Mod_Screamer.Mod_Screamer_C", 1, 0),
        E("LoadoutEquipmentSlot_5", "/Game/World_Base/Items/Archetypes/Challenger/Skills/Battlecry_Juggernaut/Skill_Battlecry_Juggernaut.Skill_Battlecry_Juggernaut_C", 0, -1),
        E("LoadoutEquipmentSlot_6", "/Game/World_Base/Items/Archetypes/Handler/Skills/Skill_AttackDog/Skill_AttackDog.Skill_AttackDog_C", 0, -1),
        E("LoadoutEquipmentSlot_12", "/Game/World_Base/Items/Trinkets/Amulets/LetosAmulet/Amulet_LetosAmulet.Amulet_LetosAmulet_C", 0, -1),
        E("LoadoutEquipmentSlot_8", "/Game/World_Fae/Items/Trinkets/Rings/FaeWarriorRing/Ring_FaeWarriorRing.Ring_FaeWarriorRing_C", 0, -1),
        E("LoadoutEquipmentSlot_9", "/Game/World_Jungle/Items/Trinkets/Rings/BerserkersCrest/Ring_BerserkersCrest.Ring_BerserkersCrest_C", 0, -1),
        E("LoadoutEquipmentSlot_10", "/Game/World_Labyrinth/Items/Trinkets/Rings/DenseSiliconRing/Ring_DenseSiliconRing.Ring_DenseSiliconRing_C", 0, -1),
        E("LoadoutEquipmentSlot_11", "/Game/World_Root/Items/Trinkets/Rings/BurdenOfTheAudacious/Ring_BurdenOfTheAudacious.Ring_BurdenOfTheAudacious_C", 0, -1),
        E("LoadoutEquipmentSlot_13", "/Game/World_Base/Items/Armor/Leto2/Armor_Head_Leto2.Armor_Head_Leto2_C", 0, -1),
        E("LoadoutEquipmentSlot_14", "/Game/World_Base/Items/Armor/Leto2/Armor_Body_Leto2.Armor_Body_Leto2_C", 0, -1),
        E("LoadoutEquipmentSlot_15", "/Game/World_Base/Items/Armor/Leto2/Armor_Gloves_Leto2.Armor_Gloves_Leto2_C", 0, -1),
        E("LoadoutEquipmentSlot_16", "/Game/World_Base/Items/Armor/Leto2/Armor_Legs_Leto2.Armor_Legs_Leto2_C", 0, -1),
        E("LoadoutEquipmentSlot_2", "/Game/World_Base/Items/Archetypes/Challenger/Engram_Challenger.Engram_Challenger_C", 0, -1),
        E("LoadoutEquipmentSlot_3", "/Game/World_Base/Items/Archetypes/Handler/Engram_Handler.Engram_Handler_C", 0, -1),
    ];

    // 保留原第 1 格的遺物+碎片+稜晶與特性（就地複製，因為要先清空）
    List<PropertyBag> keepCopies = [];
    foreach (PropertyBag src in relicKeep.Concat(traitKeep))
    {
        PropertyBag c = new()
        {
            Properties = src.Properties.Select(kv =>
            {
                Property p = kv.Value;
                object? v = p.Value is ObjectProperty op ? new ObjectProperty { ObjectIndex = op.ObjectIndex } : p.Value;
                return new KeyValuePair<string, Property>(kv.Key, new Property { Name = p.Name, Type = p.Type, Index = p.Index, Size = p.Size, HasPropertyGuid = p.HasPropertyGuid, PropertyGuid = p.PropertyGuid, Value = v });
            }).ToList()
        };
        c.RefreshLookup();
        keepCopies.Add(c);
    }

    ent0.Items.Clear();
    foreach (PropertyBag e in melee) ent0.Items.Add(e);
    foreach (PropertyBag e in keepCopies) ent0.Items.Add(e);
    Console.WriteLine($"第 1 格已覆蓋為近戰 build（{ent0.Items.Count} 筆，含保留的遺物/特性 {keepCopies.Count} 筆）");
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --socket-mods: 幫配裝中開放模組槽的槍掛上模組（Index=0，槽位已有東西則跳過）
if (args.Contains("--socket-mods"))
{
    (int li, string slot, string mod)[] sockets =
    [
        (2, "LoadoutEquipmentSlot_1", "/Game/World_DLC3/Items/Mods/ShieldingShot/Mod_ShieldingShot.Mod_ShieldingShot_C"),
        (4, "LoadoutEquipmentSlot_0", "/Game/World_Fae/Items/Mods/Mod_Witchfire/Mod_Witchfire.Mod_Witchfire_C"),
    ];
    var charss = navigator.GetObjects("SavedCharacter");
    Property lrs = navigator.GetProperty("LoadoutRecords", charss[0])!;
    ArrayStructProperty lras = (ArrayStructProperty)lrs.Value!;
    // 借用第 0 格重建槽位映射與 MakeEntry 所需資料
    PropertyBag b0 = (PropertyBag)lras.Items[0]!;
    ArrayStructProperty t0 = (ArrayStructProperty)b0["Entries"].Value!;
    SaveData sds = lrs.EnclosingSaveData(navigator);
    Dictionary<string, int> sIdxMap = new();
    foreach (object? it in t0.Items)
    {
        ObjectProperty so = (ObjectProperty)((PropertyBag)it!)["Slot"].Value!;
        sIdxMap[(so.ClassName ?? "").Split(':').Last()] = so.ObjectIndex;
    }
    int socketed = 0;
    foreach ((int li, string slot, string mod) in sockets)
    {
        if (lras.Items.Count <= li) continue;
        PropertyBag rb = (PropertyBag)lras.Items[li]!;
        ArrayStructProperty ea = (ArrayStructProperty)rb["Entries"].Value!;
        int sIdx = sIdxMap[slot];
        bool has0 = ea.Items.Cast<PropertyBag>().Any(e =>
            ((ObjectProperty)e["Slot"].Value!).ObjectIndex == sIdx && e.Contains("Index") && (int)e["Index"].Value! == 0);
        if (has0) { Console.WriteLine($"  [格 {li}] {slot} 已有模組，跳過"); continue; }
        PropertyBag entry = new()
        {
            Properties =
            [
                new("Level", new Property { Name = sds.MakeFName("Level"), Type = sds.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = 0 }),
                new("Index", new Property { Name = sds.MakeFName("Index"), Type = sds.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = 0 }),
                new("ItemClass", new Property { Name = sds.MakeFName("ItemClass"), Type = sds.MakeFName("SoftObjectProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = mod }),
                new("Slot", new Property { Name = sds.MakeFName("Slot"), Type = sds.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = sIdx } }),
            ]
        };
        entry.RefreshLookup();
        ea.Items.Add(entry);
        socketed++;
        Console.WriteLine($"  [格 {li}] 掛上 {mod.Split('/').Last().Split('.').First()}");
    }
    Console.WriteLine($"共掛 {socketed} 顆模組");
    if (socketed == 0) return;
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --max-weapons: 把背包所有武器升到上限（特殊=+10、一般=+20；拳頭等不可升級者跳過）
if (args.Contains("--max-weapons"))
{
    ObjectProperty cw = characters.First(c => c.Object != null);
    Property anchorW = navigator.GetProperties("ItemBP", cw.Object!).First();
    SaveData sdw = anchorW.EnclosingSaveData(navigator);
    int upped = 0, already = 0;
    foreach (Property p in navigator.GetProperties("ItemBP", cw.Object!))
    {
        string cls = (p.Value as ObjectProperty)?.ClassName ?? "";
        if (!cls.Contains("/Weapons/")) continue;
        if (cls.Contains("Unarmed") || cls.Contains("/Fist/")) continue;
        byte target = (byte)(cls.Contains("/Special/") || cls.Contains("/Game/Events/") || cls.Contains("/World_DLC") ? 10 : 20);
        if (cls.Contains("/Standard/")) target = 20;
        UObject? inst = ((p.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty))?.Object;
        if (inst?.Properties == null) continue;
        Property? lvl = inst.Properties.Properties.FirstOrDefault(x => x.Key == "Level").Value;
        if (lvl?.Value is lib.remnant2.saves.Model.Properties.ByteProperty bp)
        {
            if (bp.EnumByte >= target) { already++; continue; }
            bp.EnumByte = target;
        }
        else
        {
            inst.Properties.Properties.Add(new("Level", new Property
            {
                Name = sdw.MakeFName("Level"), Type = sdw.MakeFName("ByteProperty"),
                Index = 0, Size = 1, HasPropertyGuid = 0, PropertyGuid = null,
                Value = new lib.remnant2.saves.Model.Properties.ByteProperty
                { EnumName = sdw.MakeFName("None"), HasPropertyGuid = 0, PropertyGuid = null, EnumByte = target, EnumValue = null }
            }));
            inst.Properties.RefreshLookup();
        }
        upped++;
    }
    Console.WriteLine($"武器升滿: {upped} 把, 原本就滿: {already} 把");
    if (upped == 0) return;
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --max-mutators: 把背包所有突變因子 (MetaGem_*) 等級設為 10
if (args.Contains("--max-mutators"))
{
    ObjectProperty cmu = characters.First(c => c.Object != null);
    Property anchorMu = navigator.GetProperties("ItemBP", cmu.Object!).First();
    SaveData sdmu = anchorMu.EnclosingSaveData(navigator);
    int upped = 0, already = 0;
    foreach (Property p in navigator.GetProperties("ItemBP", cmu.Object!))
    {
        string cls = (p.Value as ObjectProperty)?.ClassName ?? "";
        if (!cls.Contains("MetaGem_")) continue;
        UObject? inst = ((p.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty))?.Object;
        if (inst?.Properties == null) continue;
        Property? lvl = inst.Properties.Properties.FirstOrDefault(x => x.Key == "Level").Value;
        if (lvl?.Value is lib.remnant2.saves.Model.Properties.ByteProperty bp)
        {
            if (bp.EnumByte == 10) { already++; continue; }
            bp.EnumByte = 10;
        }
        else
        {
            inst.Properties.Properties.Add(new("Level", new Property
            {
                Name = sdmu.MakeFName("Level"), Type = sdmu.MakeFName("ByteProperty"),
                Index = 0, Size = 1, HasPropertyGuid = 0, PropertyGuid = null,
                Value = new lib.remnant2.saves.Model.Properties.ByteProperty
                { EnumName = sdmu.MakeFName("None"), HasPropertyGuid = 0, PropertyGuid = null, EnumByte = 10, EnumValue = null }
            }));
            inst.Properties.RefreshLookup();
        }
        upped++;
    }
    Console.WriteLine($"升到 +10: {upped} 顆, 原本就滿級: {already} 顆");
    if (upped == 0) return;
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --arch-info: 印出所有 Archetype_* 物件的完整屬性（找職業等級/經驗存放處）
if (args.Contains("--arch-info"))
{
    ObjectProperty ca = characters.First(c => c.Object != null);
    Property anchorA = navigator.GetProperties("ItemBP", ca.Object!).First();
    SaveData sda = anchorA.EnclosingSaveData(navigator);
    foreach (UObject o in sda.Objects)
    {
        string p = o.ObjectPath ?? "";
        if (!p.Contains("Archetype_") || p.Contains("Engram") || p.Contains("Trait") || p.Contains("Skill") || p.Contains("Perk") || p.Contains("Award") || p.Contains("Armor")) continue;
        Console.WriteLine($"\n=== [{o.ObjectIndex}] {p} (WasLoaded={o.WasLoadedByte}, LoadedName={o.LoadedData?.Name?.Name}) ===");
        if (o.Properties != null)
            foreach (var kv in o.Properties.Properties) PrintProp(kv.Key, kv.Value, "  ");
        else Console.WriteLine("  (無屬性)");
    }
    return;
}

// --set-scrap <數量>: 把廢料設為指定數量（低於才調高，不往下調）
int scFlag = Array.IndexOf(args, "--set-scrap");
if (scFlag >= 0)
{
    int target = int.Parse(args[scFlag + 1]);
    const string scrapPath = "/Game/World_Base/Items/Materials/Scraps/Material_Scraps.Material_Scraps_C";
    ObjectProperty csc = characters.First(c => c.Object != null);
    Property? scrapItem = navigator.GetProperties("ItemBP", csc.Object!)
        .FirstOrDefault(x => x.Value is ObjectProperty op && op.ClassName == scrapPath);
    if (scrapItem == null)
    {
        AddInventoryItem(navigator, csc, scrapPath, "ItemInstanceData", target);
        Console.WriteLine($"新增廢料 x{target}");
    }
    else
    {
        UObject inst = (scrapItem.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty)!.Object!;
        Property? qp = navigator.GetProperty("Quantity", inst);
        int cur = qp?.Value is int q ? q : 0;
        if (cur >= target) { Console.WriteLine($"廢料已有 {cur}，不調整"); return; }
        if (qp != null) qp.Value = target;
        Console.WriteLine($"廢料 {cur} -> {target}");
    }
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile.Read(outPath);
    Console.WriteLine("回讀驗證 OK");
    return;
}

// --trait-points <加多少>: 增加角色未使用特性點
int tpFlag = Array.IndexOf(args, "--trait-points");
if (tpFlag >= 0)
{
    int delta = int.Parse(args[tpFlag + 1]);
    ObjectProperty ct = characters.First(c => c.Object != null);
    Property? tp = navigator.GetProperty("TraitPoints", ct.Object!);
    if (tp == null) { Console.WriteLine("找不到 TraitPoints 屬性"); return; }
    int cur = (int)tp.Value!;
    tp.Value = cur + delta;
    Console.WriteLine($"TraitPoints: {cur} -> {cur + delta}");
    Console.WriteLine($"寫入 {outPath} ...");
    SaveFile.Write(outPath, sf);
    SaveFile v3 = SaveFile.Read(outPath);
    Navigator nv3 = new(v3);
    ObjectProperty c3 = nv3.GetProperty("Characters")!.GetItems<ObjectProperty>().First(c => c.Object != null);
    Console.WriteLine($"回讀驗證 TraitPoints = {nv3.GetProperty("TraitPoints", c3.Object!)?.Value}");
    return;
}

// --loadouts: 印出配裝紀錄完整結構
if (args.Contains("--loadouts"))
{
    var chars0 = navigator.GetObjects("SavedCharacter");
    UObject ch = chars0[0];
    Property? lr = navigator.GetProperty("LoadoutRecords", ch);
    if (lr == null) { Console.WriteLine("沒有 LoadoutRecords"); return; }
    if (lr.Value is ArrayStructProperty lra)
    {
        Console.WriteLine($"LoadoutRecords 為陣列: {lra.Items.Count} 格, ElementType={lra.ElementType?.Name}, ArrIndex={lra.Index}, NameIdx={lra.NameIndex}, TypeIdx={lra.TypeIndex}");
        for (int ri = 0; ri < lra.Items.Count; ri++)
        {
            PropertyBag rb = (PropertyBag)lra.Items[ri]!;
            Console.WriteLine($"  [格 {ri}] 欄位: {string.Join(", ", rb.Properties.Select(x => $"{x.Key}({x.Value.Type?.Name},Idx={x.Value.Index},Val={(x.Value.Value is ArrayStructProperty a ? $"[{a.Items.Count}項]" : x.Value.Value)})"))}");
        }
    }
    List<Property> ls = navigator.GetProperties("Entries", lr);
    Console.WriteLine($"Entries 屬性數: {ls.Count}");
    for (int li = 0; li < ls.Count; li++)
    {
        ArrayStructProperty asp = ls[li].Get<ArrayStructProperty>();
        Console.WriteLine($"[配裝 {li}] 項目數={asp.Items.Count} ElementType={asp.ElementType?.Name} NameIdx={asp.NameIndex} TypeIdx={asp.TypeIndex}");
        foreach (object? item in asp.Items)
        {
            PropertyBag pb = (PropertyBag)item!;
            foreach (var kv in pb.Properties)
            {
                if (kv.Value.Value is ObjectProperty op)
                    Console.WriteLine($"      {kv.Key} (Object) idx={op.ObjectIndex} cls={op.ClassName}");
                else
                    Console.WriteLine($"      {kv.Key} ({kv.Value.Type?.Name}) = {kv.Value.Value}");
            }
            Console.WriteLine("      ---");
        }
    }
    return;
}

// --dump: 列出 slot 0 所有道具 ClassName（含 Quantity），供 diff 用
if (args.Contains("--dump"))
{
    ObjectProperty c0 = characters.First(c => c.Object != null);
    foreach (Property p in navigator.GetProperties("ItemBP", c0.Object!))
    {
        string cls = (p.Value as ObjectProperty)?.ClassName ?? "?";
        int qty = 1;
        try
        {
            UObject inst = ((p.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty)!).Object!;
            Property? qp = navigator.GetProperty("Quantity", inst);
            if (qp?.Value is int qv) qty = qv;
        }
        catch { }
        Console.WriteLine($"DUMP\t{cls}\t{qty}");
    }
    return;
}

bool changed = false;
for (int slot = 0; slot < characters.Count; slot++)
{
    ObjectProperty character = characters[slot];
    if (character.Object == null) { Console.WriteLine($"[slot {slot}] 空槽，跳過"); continue; }

    if (itemsFile != null)
    {
        List<Property> invProps;
        try { invProps = navigator.GetProperties("ItemBP", character.Object).ToList(); }
        catch { Console.WriteLine($"[slot {slot}] 讀不到背包，跳過"); continue; }
        if (invProps.Count == 0) { Console.WriteLine($"[slot {slot}] 背包是空的，跳過"); continue; }
        HashSet<string> ownedIds = invProps.Select(x => (x.Value as ObjectProperty)?.ClassName ?? "").ToHashSet();
        int added = 0, skipped = 0;
        foreach (string line in File.ReadLines(itemsFile))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            string[] parts = line.Split('\t');
            string id = parts[0].Trim();
            string label = parts.Length > 1 ? parts[1].Trim() : id;
            string kind = parts.Length > 2 ? parts[2].Trim() : "material";
            string instType = kind switch { "equip" => "EquipmentInstanceData", "mod" => "EquipmentModInstanceData", _ => "ItemInstanceData" };
            bool isEquip = kind is "equip" or "mod";
            int? qty = !isEquip && parts.Length > 3 && int.TryParse(parts[3], out int q) ? q : (isEquip ? null : 1);
            if (ownedIds.Contains(id)) { skipped++; continue; }
            if (!checkOnly)
            {
                AddInventoryItem(navigator, character, id, instType, qty);
                changed = true;
                Console.WriteLine($"  + {label}");
            }
            else Console.WriteLine($"  缺 {label}");
            added++;
        }
        Console.WriteLine($"[slot {slot}] 清單模式: 新增 {added}, 已有跳過 {skipped}");
        continue;
    }

    List<Property> itemProps;
    try { itemProps = navigator.GetProperties("ItemBP", character.Object).ToList(); }
    catch { Console.WriteLine($"[slot {slot}] 讀不到背包，跳過"); continue; }
    if (itemProps.Count == 0) { Console.WriteLine($"[slot {slot}] 背包是空的，跳過"); continue; }

    HashSet<string> owned = itemProps
        .Select(x => (x.Value as ObjectProperty)?.ClassName ?? "")
        .ToHashSet();

    // 角色職業概況
    var archetypes = owned.Where(x => x.Contains("/Archetypes/") && x.Contains("Engram_")).ToList();
    Console.WriteLine($"[slot {slot}] 道具 {itemProps.Count} 件, 已有 engram: {string.Join(", ", archetypes.Select(a => a.Split('/').Last().Split('.').First()))}");

    int missing = 0;
    foreach ((string name, string id) in engramMaterials)
    {
        if (owned.Contains(id)) { Console.WriteLine($"  已有 {name} 的材料"); continue; }
        missing++;
        if (!checkOnly)
        {
            AddInventoryItem(navigator, character, id, "ItemInstanceData", 1);
            changed = true;
            Console.WriteLine($"  + 加入 {name} 材料");
        }
        else Console.WriteLine($"  缺 {name} 材料");
    }

    // 合成需求: 每個 engram 10 Lumenite + 1000 Scrap
    int needLumenite = missing * 10, needScrap = missing * 1000;
    EnsureCurrency(navigator, character, lumeniteId, "Lumenite", needLumenite, checkOnly, ref changed);
    EnsureCurrency(navigator, character, scrapId, "Scrap", needScrap, checkOnly, ref changed);
}

if (checkOnly) { Console.WriteLine("(--check 模式，未寫入)"); return; }
if (!changed) { Console.WriteLine("沒有需要修改的內容。"); return; }

Console.WriteLine($"寫入 {outPath} ...");
SaveFile.Write(outPath, sf);

// 回讀驗證
Console.WriteLine("回讀驗證中 ...");
SaveFile verify = SaveFile.Read(outPath);
Navigator vnav = new(verify);
List<ObjectProperty> vchars = vnav.GetProperty("Characters")!.GetItems<ObjectProperty>();
for (int slot = 0; slot < vchars.Count; slot++)
{
    if (vchars[slot].Object == null) continue;
    List<Property> vitems;
    try { vitems = vnav.GetProperties("ItemBP", vchars[slot].Object).ToList(); } catch { continue; }
    HashSet<string> vowned = vitems.Select(x => (x.Value as ObjectProperty)?.ClassName ?? "").ToHashSet();
    List<string> targets = itemsFile != null
        ? File.ReadLines(itemsFile).Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Split('\t')[0].Trim()).ToList()
        : engramMaterials.Values.ToList();
    int have = targets.Count(vowned.Contains);
    Console.WriteLine($"[slot {slot}] 驗證: 目標道具持有 {have}/{targets.Count}");
}
Console.WriteLine("完成。");

static void EnsureCurrency(Navigator navigator, ObjectProperty character, string currencyId, string label, int need, bool checkOnly, ref bool changed)
{
    Property? cur = navigator.GetProperties("ItemBP", character.Object!)
        .FirstOrDefault(x => x.Value is ObjectProperty op && op.ClassName == currencyId);
    int haveQty = 0;
    Property? qtyProp = null;
    if (cur != null)
    {
        UObject inst = (cur.GetParent<PropertyBag>(navigator)["InstanceData"].Value as ObjectProperty)!.Object!;
        qtyProp = navigator.GetProperty("Quantity", inst);
        haveQty = qtyProp?.Value is int q ? q : 0;
    }
    Console.WriteLine($"  {label}: 現有 {haveQty}, 需要 {need}");
    if (need <= 0 || haveQty >= need || checkOnly) return;
    if (qtyProp != null)
    {
        qtyProp.Value = need;
        changed = true;
        Console.WriteLine($"  + {label} 補到 {need}");
    }
    else if (cur == null)
    {
        AddInventoryItem(navigator, character, currencyId, "ItemInstanceData", need);
        changed = true;
        Console.WriteLine($"  + 新增 {label} x{need}");
    }
}

// 幫武器 InstanceData 建立完整 Mods 結構（同 --fix-mods 的作法）
static void AddModsStruct(Navigator navigator, SaveData sd, UObject inst, string modPath)
{
    UObject modObj = new() { WasLoadedByte = 1, ObjectPath = modPath };
    sd.Objects.Add(modObj);
    modObj.ObjectIndex = sd.Objects.Count - 1;

    PropertyBag element = new()
    {
        Properties =
        [
            new("ModSlot", new Property { Name = sd.MakeFName("ModSlot"), Type = sd.MakeFName("ByteProperty"), Index = 0, Size = 1, HasPropertyGuid = 0, PropertyGuid = null, Value = new lib.remnant2.saves.Model.Properties.ByteProperty { EnumName = sd.MakeFName("None"), HasPropertyGuid = 0, PropertyGuid = null, EnumByte = 0, EnumValue = null } }),
            new("Mod", new Property { Name = sd.MakeFName("Mod"), Type = sd.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = modObj.ObjectIndex } }),
            new("ModItemID", new Property { Name = sd.MakeFName("ModItemID"), Type = sd.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = -1 }),
            new("ModLevel", new Property { Name = sd.MakeFName("ModLevel"), Type = sd.MakeFName("ByteProperty"), Index = 0, Size = 1, HasPropertyGuid = 0, PropertyGuid = null, Value = new lib.remnant2.saves.Model.Properties.ByteProperty { EnumName = sd.MakeFName("None"), HasPropertyGuid = 0, PropertyGuid = null, EnumByte = 1, EnumValue = null } }),
            new("HasSavedInstanceData", new Property { Name = sd.MakeFName("HasSavedInstanceData"), Type = sd.MakeFName("BoolProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = (byte)0 }),
            new("InstanceData", new Property { Name = sd.MakeFName("InstanceData"), Type = sd.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = -1 } }),
        ]
    };
    element.RefreshLookup();

    ArrayStructProperty arr = new()
    {
        HasPropertyGuid = 0, PropertyGuid = null,
        OuterElementType = sd.MakeFName("StructProperty"),
        NameIndex = sd.MakeFName("Mods").Index,
        TypeIndex = sd.MakeFName("StructProperty").Index,
        Size = 0, Index = 0, Count = 1,
        ElementType = sd.MakeFName("EquipmentModData"),
        Guid = new(), InnerHasPropertyGuid = 0, InnerPropertyGuid = null,
        Items = [element]
    };

    PropertyBag innerBag = new()
    {
        Properties = [new("Mods", new Property { Name = sd.MakeFName("Mods"), Type = sd.MakeFName("ArrayProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = arr })]
    };
    innerBag.RefreshLookup();

    lib.remnant2.saves.Model.Properties.StructProperty outerStruct = new()
    {
        Type = sd.MakeFName("EquipmentMods"), Guid = new(), HasPropertyGuid = 0, PropertyGuid = null, Value = innerBag
    };
    Property modsProp = new() { Name = sd.MakeFName("Mods"), Type = sd.MakeFName("StructProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = outerStruct };

    int levelIdx = inst.Properties!.Properties.FindIndex(x => x.Key == "Level");
    inst.Properties.Properties.Insert(levelIdx >= 0 ? levelIdx : inst.Properties.Properties.Count, new("Mods", modsProp));
    inst.Properties.RefreshLookup();
}

// 遞迴印出屬性樹（--inspect 用）
static void PrintProp(string key, Property prop, string indent)
{
    object? v = prop.Value;
    switch (v)
    {
        case lib.remnant2.saves.Model.Properties.StructProperty sp:
            Console.WriteLine($"{indent}prop {key} (Struct:{sp.Type?.Name}) {{");
            if (sp.Value is PropertyBag spb)
                foreach (var kv in spb.Properties) PrintProp(kv.Key, kv.Value, indent + "  ");
            else Console.WriteLine($"{indent}  {sp.Value}");
            Console.WriteLine($"{indent}}}");
            break;
        case PropertyBag pb:
            Console.WriteLine($"{indent}prop {key} ({prop.Type?.Name}) {{");
            foreach (var kv in pb.Properties) PrintProp(kv.Key, kv.Value, indent + "  ");
            Console.WriteLine($"{indent}}}");
            break;
        case ArrayStructProperty asp:
            Console.WriteLine($"{indent}prop {key} (ArrayStruct[{asp.Items.Count}] of {asp.ElementType?.Name}) [");
            int i = 0;
            foreach (object? it in asp.Items)
            {
                Console.WriteLine($"{indent}  [{i++}]");
                if (it is PropertyBag ib)
                    foreach (var kv in ib.Properties) PrintProp(kv.Key, kv.Value, indent + "    ");
                else Console.WriteLine($"{indent}    {it}");
            }
            Console.WriteLine($"{indent}]");
            break;
        case ObjectProperty op:
            Console.WriteLine($"{indent}prop {key} (Object) idx={op.ObjectIndex} cls={op.ClassName}");
            UObject? oo = op.Object;
            if (oo != null)
            {
                Console.WriteLine($"{indent}  -> ObjectPath={oo.ObjectPath} WasLoaded={oo.WasLoadedByte} LoadedName={oo.LoadedData?.Name?.Name} ExtraLen={oo.ExtraPropertiesData?.Length ?? -1}");
                if (oo.Properties != null)
                    foreach (var kv in oo.Properties.Properties) PrintProp(kv.Key, kv.Value, indent + "  ");
            }
            break;
        default:
            Console.WriteLine($"{indent}prop {key} ({prop.Type?.Name}) = {v}");
            break;
    }
}

// 以下兩個 helper 改寫自官方 examples/InventoryHelpers.cs
static void AddInventoryItem(Navigator navigator, ObjectProperty character, string itemId, string instanceDataType, int? quantity)
{
    Property anchor = navigator.GetProperties("ItemBP", character.Object!).First();
    ArrayStructProperty inventory = anchor.GetParent<PropertyBag>(navigator).GetParent<ArrayStructProperty>(navigator);
    SaveData saveData = anchor.EnclosingSaveData(navigator);

    UObject itemObject = new() { WasLoadedByte = 1, ObjectPath = itemId };
    saveData.Objects.Add(itemObject);
    itemObject.ObjectIndex = saveData.Objects.Count - 1;

    List<KeyValuePair<string, Property>> instanceProps = quantity.HasValue ? [MakeInt("Quantity", quantity.Value)] : [];
    UObject instanceData = new()
    {
        WasLoadedByte = 0,
        ObjectPath = $"/Script/GunfireRuntime.{instanceDataType}",
        ExtraPropertiesData = new byte[4],
        LoadedData = new() { OuterId = 0, Name = saveData.MakeFName(instanceDataType) },
        Properties = new() { Properties = instanceProps }
    };
    instanceData.Properties.RefreshLookup();
    saveData.Objects.Add(instanceData);
    instanceData.ObjectIndex = saveData.Objects.Count - 1;

    int newId = NextInventoryId(navigator, inventory);
    PropertyBag entry = new()
    {
        Properties =
        [
            MakeInt("ID", newId),
            MakeObjectRef("ItemBP", itemObject.ObjectIndex),
            MakeBool("New", true),
            MakeBool("Favorited", false),
            MakeBool("Hidden", false),
            MakeInt("EquipmentSlotIndex", -1),
            MakeObjectRef("InstanceData", instanceData.ObjectIndex),
        ]
    };
    entry.RefreshLookup();
    inventory.Items.Add(entry);

    KeyValuePair<string, Property> MakeInt(string name, int value) =>
        new(name, new Property { Name = saveData.MakeFName(name), Type = saveData.MakeFName("IntProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = value });

    KeyValuePair<string, Property> MakeBool(string name, bool value) =>
        new(name, new Property { Name = saveData.MakeFName(name), Type = saveData.MakeFName("BoolProperty"), Index = 0, Size = 0, HasPropertyGuid = 0, PropertyGuid = null, Value = (byte)(value ? 1 : 0) });

    KeyValuePair<string, Property> MakeObjectRef(string name, int objectIndex) =>
        new(name, new Property { Name = saveData.MakeFName(name), Type = saveData.MakeFName("ObjectProperty"), Index = 0, Size = 4, HasPropertyGuid = 0, PropertyGuid = null, Value = new ObjectProperty { ObjectIndex = objectIndex } });
}

static int NextInventoryId(Navigator navigator, ArrayStructProperty inventory)
{
    PropertyBag container = inventory.GetParent<Property>(navigator).GetParent<PropertyBag>(navigator);
    int maxId = inventory.Items.Select(x => (int)((PropertyBag)x!)["ID"].Value!).Max();
    int idGen = container.Contains("IDGen") ? (int)container["IDGen"].Value! : maxId;
    int newId = Math.Max(maxId, idGen) + 1;
    if (container.Contains("IDGen"))
        container["IDGen"].Value = newId;
    return newId;
}
